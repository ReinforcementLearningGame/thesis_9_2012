package org.rlgame.experiment;

//records the result and the number of moves
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;


public class History {

	File file;
	static String Path;
	FileWriter out;
	SimpleDateFormat sdf = new SimpleDateFormat(Settings.DATE_MASK);
	
	public History() {
		
	}

	public History(String fileName,int historyType) {
		Date myDate=new Date();
		String name= sdf.format(myDate) + fileName;

		if(historyType == 0) {
			
			if (Settings.PLAYER_W_MODE == Settings.MM_PLAYER || Settings.PLAYER_B_MODE == Settings.MM_PLAYER) {
				name=name.concat(".mmg");
			} else {
				name=name.concat(".rlg");
			}
			file=new File(Path+File.separatorChar+name);
		} else if (historyType == 1) {
			name=name.concat(".txt");
			file=new File(name);
		}
	}
	
	// creates the file, using the time the game started to name it
	public final void writeToFile(String s, String fileName, int historyType, int statsType) {
		Date myDate=new Date();

		String name = "";

		if (statsType == 1) {
			String helpName = myDate.toString();
		    helpName = helpName.substring(0,19);
		    helpName = helpName.replace(':',' ');
		    name = helpName + fileName;
		} else {
			name = sdf.format(myDate) + fileName;
		}
		
		if (historyType == 0) {
			if (Settings.PLAYER_W_MODE == Settings.MM_PLAYER || Settings.PLAYER_B_MODE == Settings.MM_PLAYER) {
				name=name.concat(".mmg");
			} else {
				name=name.concat(".rlg");
			}
			file = new File(Path + File.separatorChar + name);
		} else if (historyType == 1) {
			name = name.concat(".txt");
			file = new File(name);
		}

		try {
			out = new FileWriter(file);
			out.write(s);
			out.close();
		} catch (IOException e1) {
            System.out.println("IO Exception on writeToFile Method" + e1.getMessage());			
		}
	}

	//updates the file
	public final void writeToFile(String s){
		try {
			out = new FileWriter(file, true);
            out.write(s);
            out.close();
        } catch (IOException ex) {
            System.out.println("IO Exception on writeToFile Method"  + ex.getMessage()) ;
        }
	}
	
	
}
