package org.rlgame.gameplay;



import java.util.Vector;

import org.rlgame.common.*;
import org.rlgame.experiment.Settings;
import org.rlgame.ai.AIAgent;

public class RLPlayer implements IPlayer{
	private int id; //id stands for the turn
	private int playerType;
	private int turn;
	
	private AIAgent aiAgent;
	private StringBuffer movesLog;
	

	  
	public RLPlayer(int ident) {
		this.id = ident;
		this.turn = ident;
		this.movesLog = new StringBuffer();
		this.playerType =  Settings.RL_PLAYER;

		
		/*Instatiate AIAgent with the game mode info*/
		aiAgent = new AIAgent(this.turn, 
				(this.turn == Settings.WHITE_PLAYER ? Settings.eGreedyWhite : Settings.eGreedyBlack),
				Settings.NEURAL_INPUT_SIZE, 
				(this.turn == Settings.WHITE_PLAYER ? Settings.whiteNeuralHiddenSize  : Settings.blackNeuralHiddenSize), 
				Settings.NEURAL_OUTPUT_SIZE, 
				(this.turn == Settings.WHITE_PLAYER ? Settings.whiteGamma : Settings.blackGamma),
				(this.turn == Settings.WHITE_PLAYER ? Settings.whiteLamda : Settings.blackLamda),
				(this.turn == Settings.WHITE_PLAYER ? Settings.whiteVWeightsName : Settings.blackVWeightsName),
				(this.turn == Settings.WHITE_PLAYER ? Settings.whiteWWeightsName : Settings.blackWWeightsName)
				);
	}

	public int getId() {
		return id;
	}

	public int getPlayerType() {
		return playerType;
	}

	public StringBuffer getMovesLog() {
		return movesLog;
	}

	// RL Mode
	public void pickMove(GameState passedGameState) {

		Vector<ObservationCandidateMove> movesVector = passedGameState.getAllPossibleMovesForPlayer(this.turn, passedGameState.getGameBoard());
		
		AgentAction moveResult = aiAgent.pickPlayerMove(movesVector); 
		
		Pawn chosenPawn = (Pawn) passedGameState.getPlayerPawns(this.turn)[moveResult.getPawnId()];
		Square tagetSquare = (Square) passedGameState.getGameBoard()[moveResult.getTargetCoordX()][moveResult.getTargetCoordY()];
		
		this.playSelectedMove(chosenPawn, tagetSquare, moveResult.isExploitMode(), moveResult.getMaxValue(), passedGameState);

//		passedGameState.printGameBoard();
		
		//In movesrec environment reward has already been communicated
		//however now we get the reward again (we should have searched the vector by coordinates in order to locate it)
		double environmentReward = passedGameState.getReward(this.turn);
		
		aiAgent.applySelectedMoveReward(moveResult.isExploitMode(), passedGameState.getNetworkInput(), environmentReward, passedGameState.isFinal());		
	}	
	
	private void playSelectedMove(Pawn chosenPawn, Square targetSquare, boolean isBestMove, double maxValue, GameState passedGameState) {
		String movement = "" + chosenPawn.getPosition().getXCoord() + ","
				+ chosenPawn.getPosition().getYCoord() + "->" 
				+ targetSquare.getXCoord() + ","
				+ targetSquare.getYCoord() + "->" + maxValue;

		// move the pawn
		chosenPawn.movePawn(chosenPawn.getPosition(), targetSquare);
	
		// check for dead pawns
		passedGameState.refreshGameState();

		//TODO check for validity
		passedGameState.pawnsToBinaryArray();

		movement += passedGameState.getPositionOfDeletedPawns();
		
		addMoveLog(movement);
		
		passedGameState.setPositionOfDeletedPawns("");

//		passedGameState.printGameBoard();
		
	}	
	

	// TODO PositionTag???
	public String positionTag(Pawn[] whitePawn, Pawn[] blackPawn) {
		String answer = "";
		int[] whiteIndex = new int[Settings.NUMOFPAWNS];
		int[] blackIndex = new int[Settings.NUMOFPAWNS];
		int temp, j;
		for (int i = 0; i < Settings.NUMOFPAWNS; i++) {
			whiteIndex[i] = whitePawn[i].pawn2Tag();
			blackIndex[i] = blackPawn[i].pawn2Tag();
		}
		for (int i = 1; i < Settings.NUMOFPAWNS; i++) {
			temp = whiteIndex[i];
			j = i - 1;
			while ((j >= 0) && (whiteIndex[j] > temp)) {
				whiteIndex[j + 1] = whiteIndex[j];
				j = j - 1;
			}
			whiteIndex[j + 1] = temp;
		}
		for (int i = 1; i < Settings.NUMOFPAWNS; i++) {
			temp = blackIndex[i];
			j = i - 1;
			while ((j >= 0) && (blackIndex[j] > temp)) {
				blackIndex[j + 1] = blackIndex[j];
				j = j - 1;
			}
			blackIndex[j + 1] = temp;
		}
		for (int i = 0; i < Settings.NUMOFPAWNS; i++)
			answer += whiteIndex[i];
		answer += ":";
		for (int i = 0; i < Settings.NUMOFPAWNS; i++)
			answer += blackIndex[i];

		return answer;
	}
	


	
	public void finishGameSession() {
		aiAgent.finishGameSession();
	}
	
	
	public void addMoveLog(String s) {
		movesLog.append(s);
		movesLog.append("\n");

	}

}
