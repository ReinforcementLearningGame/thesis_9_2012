package org.rlgame.gameplay;

import java.util.Random;
import java.util.StringTokenizer;
import org.rlgame.experiment.History;
import org.rlgame.experiment.Settings;

/*
 * 
 * Spiel is ''game'' in german
 * 
 */

public class Spiel {
	private GameState currentGameState;
	private IPlayer whitePlayer; 
	private IPlayer blackPlayer; 
	
	public Spiel() {
		Pawn [] whitePawn = new Pawn[Settings.NUMOFPAWNS];
		Pawn [] blackPawn = new Pawn[Settings.NUMOFPAWNS];

		for (int i = 0; i < Settings.NUMOFPAWNS; i++) {
			whitePawn[i] = new Pawn(i, true);
			blackPawn[i] = new Pawn(i, false);
		}
		currentGameState = new GameState(whitePawn, blackPawn);

		if (Settings.PLAYER_W_MODE == Settings.MM_PLAYER) {
			whitePlayer = new MMPlayer(Settings.WHITE_PLAYER, Settings.PLAYER_W_PLIES, Settings.BLACK_PLAYER);
		} else if (Settings.PLAYER_W_MODE == Settings.RANDOM_PLAYER) {
			whitePlayer = new RandomPlayer(Settings.WHITE_PLAYER);
		} else if (Settings.PLAYER_W_MODE == Settings.HUMAN_PLAYER) {
			System.out.println("[ Human mode isn't supported in the current version : Program execution will be finished]");
			System.exit(0);
		} else {
			//Settings.RL_PLAYER
			whitePlayer = new RLPlayer(Settings.WHITE_PLAYER);
		}

		if (Settings.PLAYER_B_MODE == Settings.MM_PLAYER) {
			blackPlayer = new MMPlayer(Settings.BLACK_PLAYER, Settings.PLAYER_B_PLIES, Settings.WHITE_PLAYER);			
		} else if (Settings.PLAYER_B_MODE == Settings.RANDOM_PLAYER) {
			blackPlayer = new RandomPlayer(Settings.BLACK_PLAYER);
		} else if (Settings.PLAYER_B_MODE == Settings.HUMAN_PLAYER) {
			System.out.println("[ Human mode isn't supported in the current version : Program execution will be finished]");
			System.exit(0);
		} else  {
			//Settings.RL_PLAYER
			blackPlayer = new RLPlayer(Settings.BLACK_PLAYER);
		}
	
	
	}

	// A new game session/experiment is executed each time playSession method is called
	public String [] playSession() {
		String [] gameResult = {"", ""};
		/* 
		 * counter is used in order to not let a game last forever, 
		 * the maximum number of moves is 10000
		*/
		int counter = 1; 
	    int winner = 0;

	    if (Settings.FIRST_TURN == Settings.WHITE_PLAYER) {
	    	while ((! currentGameState.isFinal()) && (counter < Settings.MAX_MOVES_COUNTER)) {
				whitePlayer.pickMove(currentGameState);

				if (! currentGameState.isFinal()) {
					blackPlayer.pickMove(currentGameState);
					//is there any chance that Black last move leads to
					//a white win due to deleted pawns?
					if (currentGameState.isFinal()) {
						winner = Settings.BLACK_PLAYER;
					}
				} else {
					//is there any chance that White last move leads to
					//a Black win due to deleted pawns?
					winner = Settings.WHITE_PLAYER;
				}
				counter++;
	    	}
	    } else {
			blackPlayer.pickMove(currentGameState);

			if (! currentGameState.isFinal()) {
				whitePlayer.pickMove(currentGameState);
				//is there any chance that White last move leads to
				//a black win due to deleted pawns?
				if (currentGameState.isFinal()) {
					winner = Settings.WHITE_PLAYER;
				}
			} else {
				//is there any chance that White last move leads to
				//a Black win due to deleted pawns?
				winner = Settings.BLACK_PLAYER;
			}
			counter++;
	    }
		
		if (counter < Settings.MAX_MOVES_COUNTER && winner > 0)  {
			
			//stats used for the current report
			gameResult[0] = "" + (--counter) + "\n";
			gameResult[0] += (winner == Settings.WHITE_PLAYER ? "aspros" : "mavros") + "\n";
			
			//Extended stats
			gameResult[1] = "" + (--counter) + "|";
			gameResult[1] += (winner == Settings.WHITE_PLAYER ? "aspros" : "mavros") + "|";
			gameResult[1] += currentGameState.getFinalStateStats();

			storeGameMovesAndStats();
		} else {
			System.out.println("Counter is " + String.valueOf(counter));
		}

		//call finish game on each player
		//aka store neural network weights info
		whitePlayer.finishGameSession();
		blackPlayer.finishGameSession();
		
		return gameResult;
	}


	public void storeGameMovesAndStats() {
		
		String wHistory = whitePlayer.getMovesLog().toString(); 
		String bHistory = blackPlayer.getMovesLog().toString(); 
		
		History gameHistory = new History();
		

		StringTokenizer stW = new StringTokenizer(wHistory.replace('\n', ' '));
		StringTokenizer stB = new StringTokenizer(bHistory.replace('\n', ' '));
		String gameMoves = "";
		
		while (stB.hasMoreTokens()) {
			gameMoves += stW.nextToken() + "\t" + stB.nextToken() + "\n";
		}

		// o aspros mporei na exei mia akomi kinisi => check it
		if (stW.hasMoreTokens()) {
			gameMoves += stW.nextToken() + '\n';
		}
		
		gameHistory.writeToFile(gameMoves,
				"_cVSc_" + Settings.DIMBOARD + "_" + Settings.DIMBASE + "_" + Settings.NUMOFPAWNS
						+ "_game_" + Math.abs(new Random().nextInt()), 0, 1);
	}

    
}
