/*
 * Copyright 2008 Brian Tanner
 * http://rl-glue-ext.googlecode.com/
 * brian@tannerpages.com
 * http://brian.tannerpages.com
 * 
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 * 
 *      http://www.apache.org/licenses/LICENSE-2.0
 * 
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
* 
*  $Revision: 676 $
*  $Date: 2009-02-08 18:15:04 -0700 (Sun, 08 Feb 2009) $
*  $Author: brian@tannerpages.com $
*  $HeadURL: http://rl-glue-ext.googlecode.com/svn/trunk/projects/codecs/Java/examples/skeleton-sample/SkeletonEnvironment.java $
* 
*/

import org.rlcommunity.rlglue.codec.EnvironmentInterface;
import org.rlcommunity.rlglue.codec.types.Action;
import org.rlcommunity.rlglue.codec.types.Observation;
import org.rlcommunity.rlglue.codec.types.Reward_observation_terminal;
import org.rlcommunity.rlglue.codec.util.EnvironmentLoader;
import org.rlcommunity.rlglue.codec.taskspec.TaskSpecVRLGLUE3;
import org.rlcommunity.rlglue.codec.taskspec.TaskSpec;
import org.rlcommunity.rlglue.codec.taskspec.ranges.IntRange;
import org.rlcommunity.rlglue.codec.taskspec.ranges.DoubleRange;


/**
 *  This is a very simple environment with discrete observations corresponding to states labeled {0,1,...,19,20}
    The starting state is 10.

    There are 2 actions = {0,1}.  0 decrements the state, 1 increments the state.

    The problem is episodic, ending when state 0 or 20 is reached, giving reward -1 or +1, respectively.  The reward is 0 on 
    all other steps.
 * @author Brian Tanner
 */
public class TurnsEnvironment implements EnvironmentInterface {
    private int turn=1;
    private final int DIMBOARDX = 7;
    private final int DIMBOARDY = 6;
    private int [][] grid;
    
    public String env_init() {
		//Create a task spec programatically.  
		//This task spec encodes that state, action, and reward space for the problem.
		//You could forgo the task spec if your agent and environment have been created specifically 
		//	to work with each other
		//ie, there is no need to share this information at run time.  You could also use your own ad-hoc 
		// task specification language,
		//or use the official one but just hard code the string instead of constructing it this way.
    	
    	return "";
    }

    public Observation env_start() {
    	grid = new int[DIMBOARDX][DIMBOARDY];
    	
		for (int i = 0; i < DIMBOARDX; i++) {
			for (int j = 0; j < DIMBOARDY; j++) {
				grid[i][j] = 0;
			}
		}
    	
        turn=1;
        Observation returnObservation=new Observation(50,7,7);
        returnObservation.intArray[0]=turn;
        for (int i = 1; i < 43; i++) {
        	returnObservation.intArray[i] = 0;
        }
        
		//fill in the possibleMoves Part
		getAllPossibleMoves(returnObservation);

		
        System.out.println("Start observation :  White Turn");

        //First Observation is the initial game state
        return returnObservation;
    }

    public Reward_observation_terminal env_step(Action thisAction) {
        boolean episodeOver=false;
        double theReward=0.0d;

        
        fillGrid(turn, thisAction.intArray[1]);
        int result = checkResult(this.grid);
        if(result!=-1) {
        	episodeOver=true;
        	if (result != 0 ) {
        		theReward=100.0d;
        	}
        }

        if (turn == 1) {
	        System.out.println("White Action value: " + thisAction.intArray[1] + " Reward " + theReward + " current state ");

        } else {
	        System.out.println("Black Action value: " + thisAction.intArray[1] + " Reward " + theReward + " current state ");
        }

        Observation returnObservation=new Observation(50,7,7);
        returnObservation.intArray[0]=turn;
        
    	
		for (int column = 0; column < DIMBOARDX; column++) {
			for (int row = 0; row < DIMBOARDY; row++) {
				returnObservation.intArray[column * 6 + row + 1] = grid[column][row];
			}
		}
		//fill in the possibleMoves Part
		getAllPossibleMoves(returnObservation);
		
        
        
        if (! episodeOver) {
        	turn = ((turn == 1) ? 2 : 1);
        	printGrid();
        } else {
        	System.out.println(result == 0 ? "Tie" : result == 1 ? "White Wins" : "Black Wins");  
        	printGrid();
        }
        
        Reward_observation_terminal returnRewardObs=new Reward_observation_terminal(theReward, returnObservation, episodeOver);
        return returnRewardObs;
    }

    public void env_cleanup() {

    }

    public String env_message(String message) {
        if(message.equals("which turn?"))
            return "Environment Turn :" + String.valueOf(turn);

	return "I don't know how to respond to your message";
    }
    
   /**
     * This is a trick we can use to make the agent easily loadable.
     * @param args
     */
    public static void main(String[] args){
        EnvironmentLoader theLoader=new EnvironmentLoader(new TurnsEnvironment());
        theLoader.run();
    }


	//todo new check validity
	public void fillGrid(int turn, int column) {
		
		for (int j = 0; j < DIMBOARDY; j++) {
			if( grid[column][j] == 0 ) {
				grid[column][j] = turn;
				break;
			}
		}
	}

	public int [][] fillGrid(int [][] cloneGrid, int turn, int column) {
		
		for (int j = 0; j < DIMBOARDY; j++) {
			if( cloneGrid[column][j] == 0 ) {
				cloneGrid[column][j] = turn;
				break;
			}
		}
		
		return cloneGrid;
	}

	public int[][] cloneGrid() {
		int [][] gridCopy = new int[DIMBOARDX][DIMBOARDY];
		
		for (int i = 0; i < DIMBOARDX; i++) {
			for (int j = 0; j < DIMBOARDY; j++) {
				gridCopy[i][j] = grid[i][j];
			}
		}
		return gridCopy;
	}

	public void printGrid() {
		for (int j = DIMBOARDY - 1; j >= 0 ; j--) {
			for (int i = 0; i < DIMBOARDX; i++) {
				System.out.print(grid[i][j] + " ");
			}
			System.out.println(" ");
		}
	}
	
	//todo new check validity
	public void getAllPossibleMoves(Observation obs) {
		int [] possibleMoves = new int[DIMBOARDX];
		
		for (int i = 0; i < DIMBOARDX; i++) {
			possibleMoves[i] = -1;
		}
		
		for (int i = 0; i < DIMBOARDX; i++) {
			for (int j = 0; j < DIMBOARDY; j++) {
				if( grid[i][j] == 0 ) {
					possibleMoves[i] = j;
					break;
				}
			}
		}
		 
		for (int i = 43; i < 50; i++) {
			obs.intArray[i] = possibleMoves[i - 43];
        }

		for (int i = 0; i < DIMBOARDX; i++) {
			if (possibleMoves[i] > -1) {
				int [][] gridCopy = cloneGrid();
				gridCopy = fillGrid(gridCopy, turn, possibleMoves[i]);
				int state = checkResult(gridCopy);
				double reward = getReward(turn, state);
				//TODO
				obs.doubleArray[i] = reward;
				
				obs.charArray[i] = ( state == -1 ? 'N' : (state == 0 ? 'T' : (state == 1 ? 'W' : 'B')) );
			} else {
				obs.doubleArray[i] = -1;
				
				obs.charArray[i] = ' ';
			}
		}
	}
    
	/**
	* The hasWon method.
	*
	* This method returns 
	* -1 if none wins
	* 0 if tie
	* 1 if white wins
	* 2 if black wins
	* 
	* players has won the game.
	*/
	public int checkResult(int [][] grid) {
		boolean status = false;
		int result = -1;
		// check for a horizontal win
		for (int row=0; row<6; row++) {
			for (int column=0; column<4; column++) {
				if (grid[column][row] != 0 &&
						grid[column][row] == grid[column+1][row] &&
						grid[column][row] == grid[column+2][row] &&
						grid[column][row] == grid[column+3][row]) {
					status = true;
					result = grid[column][row];
				}
			}
		}
		
		// check for a vertical win
		for (int row=0; row<3; row++) {
			for (int column=0; column<7; column++) {
				if (grid[column][row] != 0 &&
						grid[column][row] == grid[column][row+1] &&
						grid[column][row] == grid[column][row+2] &&
						grid[column][row] == grid[column][row+3]) {
					status = true;
					result = grid[column][row];
				}
			}
		}

		// check for a diagonal win (positive slope)
		for (int row=0; row<3; row++) {
			for (int column=0; column<4; column++) {
				if (grid[column][row] != 0 &&
						grid[column][row] == grid[column+1][row+1] &&
						grid[column][row] == grid[column+2][row+2] &&
						grid[column][row] == grid[column+3][row+3]) {
					status = true;
					result = grid[column][row];
				}
			}
		}
		
		// check for a diagonal win (negative slope)
		for (int row=3; row<6; row++) {
			for (int column=0; column<4; column++) {
				if (grid[column][row] != 0 &&
						grid[column][row] == grid[column+1][row-1] &&
						grid[column][row] == grid[column+2][row-2] &&
						grid[column][row] == grid[column+3][row-3]) {
					status = true;
					result = grid[column][row];
				}
			}
		}
		
		//check for tie
		if (result == -1) {
			boolean isTie = true;
			for (int column = 0; column < DIMBOARDX; column++) {
				if (grid[column][DIMBOARDY - 1] == 0) {
					isTie = false;
					break;
				}
			}
			
			if (isTie) {
				result = 0;
			}
		}
		
		return result;
	}
    
	private final double getReward(int turn, int finalState) {
		//-1 live
		//0 final tie
		//1 final white wins
		//2 final black wins
		
		if (finalState != -1 & finalState != 0) {
			return  100;
		} 

		return 0;
	}  
    
}
