public class AIConstants {

	
	static final int DIMBOARDX=7;   // board size Horizontal
	static final int DIMBOARDY=6;   // board size Vertical
	static final int NUMOFPAWNS=21; // easy to understand
	static final int MAX_NUM_PAWN_MOVES = 7;	   
		
	
	//RLGame 2 * NEURAL_INPUT_SIZE will be the actual input size
	static final int NEURAL_HIDDEN_SIZE = DIMBOARDX * DIMBOARDY + 3;
	static final int NEURAL_INPUT_SIZE = 2 * NEURAL_HIDDEN_SIZE;
	static final int NEURAL_OUTPUT_SIZE = 1;

	static final int WHITE_PLAYER = 1;
	static final int BLACK_PLAYER = 2;	
	
	public static double eGreedyWhite	= 0.9;
	public static double eGreedyBlack 	= 0.9;
	public static double alpha 			= 0.001;
	public static double lambda 		= 0.5;
	
	public static double whiteGamma		= 0.95;
	public static double blackGamma		= 0.95;
	public static double whiteLamda		= 0.5;
	public static double blackLamda		= 0.5;	
	
	public static double whiteReward	= 100;
	public static double blackReward	= 100;
	

	static final int SINGLE_PLAYER_GAME_MODE = 1; /*For future use*/
	static final int TWO_PLAYERS_GAME_MODE = 2; /*White,  Black mode*/	
	
}
