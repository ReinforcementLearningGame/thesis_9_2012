/*
 * Copyright 2008 Brian Tanner
 * http://rl-glue-ext.googlecode.com/
 * brian@tannerpages.com
 * http://brian.tannerpages.com
 * 
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 * 
 *      http://www.apache.org/licenses/LICENSE-2.0
 * 
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 * 
 *  $Revision: 676 $
 *  $Date: 2009-02-08 18:15:04 -0700 (Sun, 08 Feb 2009) $
 *  $Author: brian@tannerpages.com $
 *  $HeadURL: http://rl-glue-ext.googlecode.com/svn/trunk/projects/codecs/Java/examples/skeleton-sample/SkeletonExperiment.java $
 * 
 */

import java.io.File;

import org.rlcommunity.rlglue.codec.RLGlue;
import org.rlcommunity.rlglue.codec.types.Observation_action;
import org.rlcommunity.rlglue.codec.types.Reward_observation_action_terminal;


/**
 *
 * @author Brian Tanner
 */
public class TurnsExperiment {

    private int whichEpisode = 0;

	private static int gamesNumber = 10;
	private static int roundsNumber = 5;
    
    public void runExperiment() {
        System.out.println("\n\n----------Stepping through an episode----------");
        /*We could also start over and do another experiment */
        String taskSpec = RLGlue.RL_init();

        /*We could run one step at a time instead of one episode at a time */
        /*Start the episode */
        Observation_action startResponse = RLGlue.RL_start();

        /*Run one step */
        Reward_observation_action_terminal stepResponse = RLGlue.RL_step();

        int whiteCounter = 1;
        int blackCounter = 1;
        /*Run until the episode ends*/
        while (stepResponse.terminal != 1) {
            stepResponse = RLGlue.RL_step();
            if (stepResponse.terminal != 1) {
                /*Could optionally print state,action pairs */
            //    System.out.println("Step observation and action were: " + stepResponse.o.intArray[1] + " and: " + stepResponse.a.intArray[1] + " turn obs : " + String.valueOf(stepResponse.o.intArray[0]) + " turn action : " + String.valueOf(stepResponse.a.intArray[0]));

                if (stepResponse.o.intArray[0] == 1) {
                	whiteCounter++;
                } else {
                	blackCounter++;
                }
            } else {
            	System.out.println("Final action were: " + stepResponse.a.intArray[1] + " turn obs : " + String.valueOf(stepResponse.o.intArray[0]) + " turn action : " + String.valueOf(stepResponse.a.intArray[0]));
            	
            }
        }

        System.out.println("\n\n----------Summary----------");
        System.out.println("WhiteCounter :" + whiteCounter + "BlackCounter : " + blackCounter);

    	
        int totalSteps = RLGlue.RL_num_steps();
        double totalReward = RLGlue.RL_return();
        System.out.println("It ran for " + totalSteps + " steps, total reward was: " + totalReward);
        
        RLGlue.RL_cleanup();


    }

    public static void main(String[] args) {
        TurnsExperiment theExperiment = new TurnsExperiment();
        
        TurnsExperiment.argumentsValidation(args);

        for (int kk = 0; kk < roundsNumber; kk++) {
			for (int i = 0; i < gamesNumber; i++) {
	        	System.out.println("Round : " + kk + " Game : " + i + " Started............"); 
	        	theExperiment.runExperiment();
	        	System.out.println("Round : " + kk + " Game : " + i + " Ended............");
			}
		}
    }
    
    
    private static void argumentsValidation(String[] args) {
    	
    	String help = "\nRLGame By Dimitris Kalles & Panagiotis Kanellopoulos\n"
    			+ "\n\t\t##SWITHES##\n"
    			+ "\n\t-h Shows the current screen"
    			+ "\n\t-g Enter the number of games to be executed in each round"
    			+ "\n\t-r Enter the number of game rounds"
    			+ "\n\t-wg Enter the discount rate for the white player"
    			+ "\n\t-wl Enter the credit assignment factor for the white player"
    			+ "\n\t-bg Enter the discount rate for the black player"
    			+ "\n\t-bl Enter the credit assignment factor for the black player"
    			+ "\n\t-wr Enter the reward value for the white player"
    			+ "\n\t-br Enter the reward value for the black player"
    			+ "\n\t-we Enter the e-greedy policy number for the white player"
    			+ "\n\t-be Enter the e-greedy policy number for the black player\n";

    	if (args.length == 1 && args[0].contentEquals("-h")) {
    		System.out.print(help);
    		System.exit(0);
    	}

    	if (args.length == 0) {

    	} else if (args.length > 20) {
    		System.out.print("\nToo many arguments.Termination\n");
    		return;
    	} else {
    		for (int l = 0; l < args.length; l++) {
    			if (l % 2 == 0) {
    				if (!args[l].startsWith("-")) {
    					System.out.printf("\nThe %dth argument has no switch (-). Defaulting...", l + 1);
    					continue;
    				}
    				if (args[l].contentEquals("-g")) {
    					try {
    						gamesNumber = Integer.parseInt(args[l + 1]);
    						System.out.printf("\nThe games per round number has been set up in %s.", args[l + 1]);
    					} catch (NumberFormatException numberFormatException) {
    						System.out.print("\nInvalid value in games per round number argument. " + numberFormatException.getMessage() + "Defaulting to 100");
    					}
    					continue;
    				}
    				if (args[l].contentEquals("-r")) {
    					try {
    						roundsNumber = Integer.parseInt(args[l + 1]);
    						System.out.printf("\nThe games round number has been set up in %s.", args[l + 1]);
    					} catch (NumberFormatException numberFormatException) {
    						System.out.print("\nInvalid value in games round number argument. " + numberFormatException.getMessage() + "Defaulting to 10");
    					}
    					continue;
    				}
    				if (args[l].equals("-wg")) {
    					try {
//    						Spiel.whiteGamma = Double.parseDouble(args[l + 1]);
    						
    						AIConstants.whiteGamma = Double.parseDouble(args[l + 1]);
    						System.out.printf("\nThe discount rate number for the white player has been set up in %s.", args[l + 1]);
    					} catch (NumberFormatException numberFormatException) {
    						System.out.print("\nInvalid value in discount rate number argument for the white player. " + numberFormatException.getMessage() + "Defaulting to 0.95");
    					}
    					continue;
    				}
    				if (args[l].equals("-wl")) {
    					try {
    						//Spiel.whiteLamda = Double.parseDouble(args[l + 1]);
    						AIConstants.whiteLamda = Double.parseDouble(args[l + 1]);
    						System.out.printf("\nThe credit asignment factor for the white player has been set up in %s.", args[l + 1]);
    					} catch (NumberFormatException numberFormatException) {
    						System.out.print("\nInvalid value in credit asignment factor argument for the white player. " + numberFormatException.getMessage() + "Defaulting to 0.5");
    					}
    					continue;
    				}
    				if (args[l].equals("-bg")) {
    					try {
    						//Spiel.blackGamma = Double.parseDouble(args[l + 1]);
    						AIConstants.blackGamma = Double.parseDouble(args[l + 1]);
    						System.out.printf("\nThe discount rate number for the black player has been set up in %s.", args[l + 1]);
    					} catch (NumberFormatException numberFormatException) {
    						System.out.print("\nInvalid value in discount rate number argument for the black player. " + numberFormatException.getMessage() + "Defaulting to 0.95");
    					}
    					continue;
    				}
    				if (args[l].equals("-bl")) {
    					try {
    						//Spiel.blackLamda = Double.parseDouble(args[l + 1]);
    						AIConstants.blackLamda = Double.parseDouble(args[l + 1]);
    						System.out.printf("\nThe credit asignment factor for the black player has been set up in %s.", args[l + 1]);
    					} catch (NumberFormatException numberFormatException) {
    						System.out.print("\nInvalid value in credit asignment factor argument for the black player. " + numberFormatException.getMessage() + "Defaulting to 0.5");
    					}
    					continue;
    				}
    				if (args[l].equals("-wr")) {
    					try {
    						//Position.whiteReward = Double.parseDouble(args[l + 1]);
    						AIConstants.whiteReward = Double.parseDouble(args[l + 1]);
    						System.out.printf("\nThe reward value for the white player has been set up in %s.", args[l + 1]);
    					} catch (NumberFormatException numberFormatException) {
    						System.out.print("\nInvalid value in reward value argument for the white player. " + numberFormatException.getMessage() + "Defaulting to 100");
    					}
    					continue;
    				}
    				if (args[l].equals("-br")) {
    					try {
    						//Position.blackReward = Double.parseDouble(args[l + 1]);
    						AIConstants.blackReward = Double.parseDouble(args[l + 1]);
    						System.out.printf("\nThe reward value for the black player has been set up in %s.", args[l + 1]);
    					} catch (NumberFormatException numberFormatException) {
    						System.out.print("\nInvalid value in reward value argument for the black player. " + numberFormatException.getMessage() + "Defaulting to 100");
    					}
    					continue;
    				}
    				if (args[l].equals("-we")) {
    					try {
    						//Player.eGreedyWhite = Double.parseDouble(args[l + 1]);
    						AIConstants.eGreedyWhite = Double.parseDouble(args[l + 1]);
    						System.out.printf("\nThe e-Greedy policy number for the white player has been set up in %s.", args[l + 1]);
    					} catch (NumberFormatException numberFormatException) {
    						System.out.print("\nInvalid value in e-Greedy policy number argument for the white player. " + numberFormatException.getMessage() + "Defaulting to 0.9");
    					}
    					continue;
    				}
    				if (args[l].equals("-be")) {
    					try {
    						//Player.eGreedyBlack = Double.parseDouble(args[l + 1]);
    						AIConstants.eGreedyBlack = Double.parseDouble(args[l + 1]);
    						System.out.printf("\nThe e-Greedy policy number for the black player has been set up in %s.", args[l + 1]);
    					} catch (NumberFormatException numberFormatException) {
    						System.out.print("\nInvalid value in e-Greedy policy number argument for the black player. " + numberFormatException.getMessage() + "Defaulting to 0.9");
    					}
    					continue;
    				}
    				System.out.printf("\nThe %dth argument is not valid.");
    				continue;
    			}
    		}
    	}

    }
    
}
