/*
 * Copyright 2008 Brian Tanner
 * http://rl-glue-ext.googlecode.com/
 * brian@tannerpages.com
 * http://brian.tannerpages.com
 * 
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 * 
 *      http://www.apache.org/licenses/LICENSE-2.0
 * 
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
* 
*  $Revision: 676 $
*  $Date: 2009-02-08 18:15:04 -0700 (Sun, 08 Feb 2009) $
*  $Author: brian@tannerpages.com $
*  $HeadURL: http://rl-glue-ext.googlecode.com/svn/trunk/projects/codecs/Java/examples/skeleton-sample/SkeletonAgent.java $
* 
*/

import java.util.Random;
import java.util.ArrayList;

import org.rlcommunity.rlglue.codec.AgentInterface;
import org.rlcommunity.rlglue.codec.types.Action;
import org.rlcommunity.rlglue.codec.types.Observation;
import org.rlcommunity.rlglue.codec.util.AgentLoader;


/**
 *
 * @author Brian Tanner
 */
public class TurnsAgent implements AgentInterface {

    Random randGenerator = new Random();
    Action lastAction;
    Observation lastObservation;
	private int turn = 1;
	private final int DIMBOARDX = 7;
	private final int DIMBOARDY = 6;
    private NeuralNet whiteNeural; //neural net used for the 1st player
    private NeuralNet blackNeural; //neural net used for the 2nd player

    
    //We will use only the bellow private random objects
    private Random eSoftDecision;
    private Random exploreDecision;
    

	public void agent_init(String taskSpecification) {
		whiteNeural = new NeuralNet(AIConstants.WHITE_PLAYER, AIConstants.NEURAL_INPUT_SIZE, AIConstants.NEURAL_HIDDEN_SIZE, AIConstants.NEURAL_OUTPUT_SIZE, AIConstants.whiteGamma, AIConstants.whiteLamda);
		blackNeural = new NeuralNet(AIConstants.BLACK_PLAYER, AIConstants.NEURAL_INPUT_SIZE, AIConstants.NEURAL_HIDDEN_SIZE, AIConstants.NEURAL_OUTPUT_SIZE, AIConstants.blackGamma, AIConstants.blackLamda);

	    eSoftDecision = new Random();
	    exploreDecision = new Random();
	    turn = 1;
	}

    public Action agent_start(Observation observation) {
    	//Convention : Observation 
    	turn = observation.intArray[0];

    	int[] possibleMoves = new int[DIMBOARDX];
    	
    	double[] environmentRewards = new double[DIMBOARDX];
    	char[] result = new char[DIMBOARDX];
    	
    	for (int i = 43; i < 50; i++) {
    		possibleMoves[i - 43] = observation.intArray[i];
        }
    	
    	for (int i = 0; i < 7; i++) {
    		environmentRewards[i] = observation.doubleArray[i];
    		result[i] = observation.charArray[i];
    		//( state == -1 ? 'N' : (state == 0 ? 'T' : (state == 1 ? 'W' : 'B')) );
        }
    	
        int theIntAction = this.playerChooses(turn, observation);

        /**
         * Create a structure to hold 1 integer action
         * and set the value
         */
        
        Action returnAction = new Action(2, 0, 0);
        returnAction.intArray[0] = turn;
        returnAction.intArray[1] = theIntAction;

        lastAction = returnAction.duplicate();
        lastObservation = observation.duplicate();

        return returnAction;
    }

    public Action agent_step(double reward, Observation observation) {
        
    	turn = observation.intArray[0];
    	
    	
    	
    	/**
         * Choose a random action (0 or 1)
         */
        int theIntAction = this.playerChooses(turn, observation);
        
        /**
         * Create a structure to hold 1 integer action
         * and set the value (alternate method)
         */
        Action returnAction = new Action(2, 0, 0);
        returnAction.intArray[0] = turn;
        returnAction.intArray[1] = theIntAction;

        lastAction = returnAction.duplicate();
        lastObservation = observation.duplicate();

        return returnAction;
    }

    public void agent_end(double reward) {
    	System.out.println("Agent End Event Called");
    	this.storeWeights(AIConstants.WHITE_PLAYER);
    	this.storeWeights(AIConstants.BLACK_PLAYER);
    }

    public void agent_cleanup() {
        lastAction=null;
        lastObservation=null;
        turn = 1;
        
        whiteNeural = null; //neural net used for the 1st player
        blackNeural = null;

        eSoftDecision = null;
	    exploreDecision = null;
	      
    }

    public String agent_message(String message) {
        if(message.equals("which turn?"))
            return "Agent turn : " + String.valueOf(turn);
        

	return "I don't know how to respond to your message";
    }
    
    /**
     * This is a trick we can use to make the agent easily loadable.
     * @param args
     */
    
    public static void main(String[] args){
     	AgentLoader theLoader=new AgentLoader(new TurnsAgent());
        theLoader.run();
	}
    
	public int playerChooses(int turn, Observation observation) {
		int exploitItem = -1;
		int exploitState = -1;
		double maxValue = -1000;
		double exploitReward = -1000;
		int[][] exploitGrid = new int[DIMBOARDX][DIMBOARDY];
		double value; // the value of the position that occurs after making a move
		boolean bestMove; // if true-> exploit, else ->explore

    	int[] possibleMoves = new int[DIMBOARDX];
    	
    	double[] environmentRewards = new double[DIMBOARDX];
    	char[] result = new char[DIMBOARDX];
    	
        int [][] grid = new int[DIMBOARDX][DIMBOARDY] ;
        
		for (int i = 1; i < 43; i++) {
			int temp = i - 1;
			int column = (int) Math.floor(temp/DIMBOARDY);
			int row = temp - (column * DIMBOARDY);
			grid[column][row] = observation.intArray[i];
		}
		
    	for (int i = 43; i < 50; i++) {
    		possibleMoves[i - 43] = observation.intArray[i];
        }
    	
    	for (int i = 0; i < 7; i++) {
    		environmentRewards[i] = observation.doubleArray[i];
    		result[i] = observation.charArray[i];
    		//( state == -1 ? 'N' : (state == 0 ? 'T' : (state == 1 ? 'W' : 'B')) );
        }


		double eSoft = eSoftDecision.nextDouble();
		ArrayList possibleTargets = new ArrayList();
		//if eSoft is less than 0.9 then we exploit
		bestMove = (eSoft < (turn == AIConstants.BLACK_PLAYER ? AIConstants.eGreedyBlack : AIConstants.eGreedyWhite)) ? true : false; 
		int moveCounter = 0;

		for (int j = 0; j < AIConstants.MAX_NUM_PAWN_MOVES; j++) {
			if ( possibleMoves[j] != -1 ) {
				// get the value of the occuring position
				double[] aux;
				int[][] occuringGrid = grid.clone();
				occuringGrid[j][possibleMoves[j]] = observation.intArray[0];
				int state = result[j] == 'T' ? 0 :  (result[j] == 'W' ? 1 : (result[j] == 'B' ? 2 : -1)); 

				if (turn == AIConstants.BLACK_PLAYER) {
					
					this.gridToInput(AIConstants.BLACK_PLAYER, occuringGrid, state);
					aux = this.getCombinedReward(AIConstants.BLACK_PLAYER, environmentRewards[j]);
				} else {
					this.gridToInput(AIConstants.WHITE_PLAYER, occuringGrid, state);
					aux = this.getCombinedReward(AIConstants.WHITE_PLAYER, environmentRewards[j]);
				}
				moveCounter++;

				possibleTargets.add( Integer.valueOf(j) );
				value = aux[0];
				// if it is the biggest value, keep it
				if (value > maxValue) { 
					maxValue = value;
					exploitItem = j;
					exploitGrid = occuringGrid.clone();
					exploitState = state;
					exploitReward = environmentRewards[j];
				}
			}
		}
		if (bestMove) { // exploit
			if (turn == AIConstants.WHITE_PLAYER) {
				this.gridToInput(AIConstants.WHITE_PLAYER, exploitGrid, exploitState);
				// update the neural net
				whiteNeural.singleStep(exploitReward, (exploitState != -1)? true : false);
			} else {
				this.gridToInput(AIConstants.BLACK_PLAYER, exploitGrid, exploitState);
				// update the neural net
				blackNeural.singleStep(exploitReward, (exploitState != -1)? true : false);
			}
			
			return exploitItem;
			
		} else { // explore
			if (turn == AIConstants.BLACK_PLAYER) {
				blackNeural.clearEligTrace(); // clear eligibility traces
			} else {
				whiteNeural.clearEligTrace(); // clear eligibility traces
			}
			
			double explore = exploreDecision.nextDouble();
			int target = (int) (explore * moveCounter);

			int ret  =  (Integer) possibleTargets.get(target);

			int[][] occuringGrid = grid.clone();
			occuringGrid[ret][possibleMoves[ret]] = observation.intArray[0];
			int state = result[ret] == 'T' ? 0 :  (result[ret] == 'W' ? 1 : (result[ret] == 'B' ? 2 : -1)); 

			if (turn == AIConstants.WHITE_PLAYER) {
				double[] aux;
				this.gridToInput(AIConstants.WHITE_PLAYER, occuringGrid, state);
				aux = this.getCombinedReward(AIConstants.WHITE_PLAYER, environmentRewards[ret]);
				whiteNeural.setOldOutputNode(aux[0]);
			} else {
				double[] aux;
				this.gridToInput(AIConstants.BLACK_PLAYER, occuringGrid, state);
				aux = this.getCombinedReward(AIConstants.BLACK_PLAYER, environmentRewards[ret]);
				blackNeural.setOldOutputNode(aux[0]);
			}
			return ret;
		}
	}

	
	
	private double[] rewardResponse(int turn) {
		if (turn == AIConstants.WHITE_PLAYER) {
			return whiteNeural.Response();
		//} else if (turn == AIConstants.BLACK_PLAYER) {
		} else {	
			return blackNeural.Response();
		}

		//return null;	
	}	

	private final double [] getCombinedReward(int turn, double environmentReward) {
		//Environment, reinforcement learning reward
		
		//Neural, reward (the output of the last action input (gameState))
		double[] ret;
		ret = this.rewardResponse(turn);
		ret[0] += environmentReward;
		
		return ret;
	}	
	
	public final void storeWeights(int turn) {
		if (turn == AIConstants.WHITE_PLAYER) {
			this.whiteNeural.storeWeights();
		} else if (turn == AIConstants.BLACK_PLAYER) {
			this.blackNeural.storeWeights();
		}
	}
		
	private void gridToInput(int turn, int [][] grid, int state) {
		if (turn == AIConstants.WHITE_PLAYER) {
			whiteNeural.pawnsToInput(gridToBinaryArray(grid, state));
		} else if (turn == AIConstants.BLACK_PLAYER) {
			blackNeural.pawnsToInput(gridToBinaryArray(grid, state));
		}
	}
	
	
	// transforms the pawns configuration to a binary array, that we use for input to the net 
	// for each square we have 2 values,
	// one for each player, the appropriate value is set to 1 or both are set to zero 
	// finally there are 3 more values, 1 for 
	// tie result 1 for white win and another for black win
	private final double [] gridToBinaryArray(int [][] grid, int result) {
		int pos = 0;
		int shortcut = (2 * AIConstants.DIMBOARDX * AIConstants.DIMBOARDY) - 1;
		double [] inputNode = new double[AIConstants.NEURAL_INPUT_SIZE + 1]; 

		for (int i = 0; i < DIMBOARDX; i++) {
			for (int j = 0; j < DIMBOARDY; j++) {
				int whitePos = i  * (DIMBOARDX - 1)  + j;
				int blackPos = i  * (DIMBOARDX - 1)  + j + (DIMBOARDX * DIMBOARDY);
				if (grid[i][j] == 0) {
					inputNode[whitePos] = 0;
					inputNode[blackPos] = 0;
				} else if (grid[i][j] == 1) {
					inputNode[whitePos] = 1;
					inputNode[blackPos] = 0;
				} else if (grid[i][j] == 2) {
					inputNode[whitePos] = 0;
					inputNode[blackPos] = 1;
				}
			}
		}		
		inputNode[shortcut] = 0;
		inputNode[shortcut + 1] = 0;
		inputNode[shortcut + 2] = 0;
		if (result == 0) {
			inputNode[shortcut] = 1;
		} else if (result == 1) {
			inputNode[shortcut + 1] = 1;
		} else if (result == 2) {
			inputNode[shortcut + 2] = 1;
		}
		
		return inputNode;
	}
    

}
