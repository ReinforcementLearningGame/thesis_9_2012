package org.rlconnect4.gameplay;

import java.util.Random;
import java.util.Vector;

import org.rlconnect4.experiment.Settings;
import org.rlgame.common.*;

public class RandomPlayer implements IPlayer  {
	private int id; //id stands for the turn
	private int playerType;
	private int turn;
	
	private StringBuffer movesLog;
	private StringBuffer extMovesLog;
	
	private Random eRand = new Random();
	public RandomPlayer(int ident) {
		this.id = ident;
		this.turn = ident;
		this.movesLog = new StringBuffer();

		this.extMovesLog = new StringBuffer();
		extMovesLog.append("Mode:RN,Turn:");
		extMovesLog.append(this.turn);
		extMovesLog.append("\n");		
		
		this.playerType =  Settings.RANDOM_PLAYER;
		
		
		
	}

	public int getId() {
		return id;
	}

	public int getPlayerType() {
		return playerType;
	}

	public StringBuffer getMovesLog() {
		return movesLog;
	}
	
	public StringBuffer getExtMovesLog() {
		return extMovesLog;
	}
	
	// Random Mode
	public void pickMove(GameState passedGameState) {
		Vector<ObservationCandidateMove> movesVector = passedGameState.getAllPossibleMovesForPlayer(this.turn, passedGameState.getGameGrid());
		
		int movesNum = movesVector.size();
		int ee = eRand.nextInt(movesNum);
		ObservationCandidateMove selMove = movesVector.get(ee);
		
		this.playSelectedMove(selMove.getTargetCoordX(), selMove.getTargetCoordY(), passedGameState);

	}	
	
	private void playSelectedMove(int coordX, int coordY, GameState passedGameState) {
		String movement = "" + coordX + "," + coordY + "->" + 0.0d;

		// move the pawn
		passedGameState.usePawn(this.turn, coordX, coordY);
	
		if (Settings.logMode == Settings.SIMPLE_LOG || Settings.logMode == Settings.BOTH_LOG) {
			addMoveLog(movement);
		}
		
		if (Settings.logMode == Settings.EXTENDED_LOG || Settings.logMode == Settings.BOTH_LOG) {
			addExtMoveLog("RND," + movement);
		} 	
	}	
	
	public void finishGameSession() {
		
	}
	
	public void addMoveLog(String s) {
		movesLog.append(s);
		movesLog.append("\n");
	}
	
	public void addExtMoveLog(String s) {
		extMovesLog.append(s);
		extMovesLog.append("\n");

	}	
}
