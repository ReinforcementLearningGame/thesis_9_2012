package org.rlconnect4.gameplay;

import java.util.Vector;

import org.rlconnect4.experiment.Settings;
import org.rlgame.common.*;
import org.rlgame.ai.AIAgent;

public class RLPlayer implements IPlayer {
	private int id; //id stands for the turn
	private int playerType;
	private int turn;
	
	private AIAgent aiAgent;
	private StringBuffer movesLog;
	private StringBuffer extMovesLog;
	
	public RLPlayer(int ident) {
		this.id = ident;
		this.turn = ident;

		this.movesLog = new StringBuffer();
		this.extMovesLog = new StringBuffer();
		extMovesLog.append("Mode:RL,Turn:");
		extMovesLog.append(this.turn);
		extMovesLog.append("\n");
		
		
		this.playerType =  Settings.RL_PLAYER;
		/*Instatiate AIAgent with the game mode info*/
		aiAgent = new AIAgent(this.turn, 
				(this.turn == Settings.WHITE_PLAYER ? Settings.eGreedyWhite : Settings.eGreedyBlack),
				Settings.NEURAL_INPUT_SIZE, 
				(this.turn == Settings.WHITE_PLAYER ? Settings.whiteNeuralHiddenSize  : Settings.blackNeuralHiddenSize), 
				Settings.NEURAL_OUTPUT_SIZE, 
				(this.turn == Settings.WHITE_PLAYER ? Settings.whiteGamma : Settings.blackGamma),
				(this.turn == Settings.WHITE_PLAYER ? Settings.whiteLamda : Settings.blackLamda),
				(this.turn == Settings.WHITE_PLAYER ? Settings.whiteVWeightsName : Settings.blackVWeightsName),
				(this.turn == Settings.WHITE_PLAYER ? Settings.whiteWWeightsName : Settings.blackWWeightsName)
				);
	}

	public int getId() {
		return id;
	}

	public int getPlayerType() {
		return playerType;
	}

	public StringBuffer getMovesLog() {
		return movesLog;
	}
	
	public StringBuffer getExtMovesLog() {
		return extMovesLog;
	}	

	// RL Mode
	public void pickMove(GameState passedGameState) {
		Vector<ObservationCandidateMove> movesVector = passedGameState.getAllPossibleMovesForPlayer(this.turn, passedGameState.getGameGrid());
		
		AgentAction moveResult = aiAgent.pickPlayerMove(movesVector); 
		
		
		if (Settings.debugMode) {
			if (moveResult.getMaxValue() >= 100.0 || moveResult.getMaxValue() <= 0.0) {
				System.out.println(passedGameState.getGameTag() + " : RL player Turn " + String.valueOf(this.turn) + " MaxValue = " + String.valueOf(moveResult.getMaxValue()));
			}
		}
		
		this.playSelectedMove(moveResult.getTargetCoordX(), moveResult.getTargetCoordY(), moveResult.isExploitMode(), moveResult.getMaxValue(), passedGameState);

		//In movesrec environment reward has already been communicated
		//however now we get the reward again (we should have searched the vector by coordinates in order to locate it)
		double environmentReward = passedGameState.getReward(this.turn);
		
		aiAgent.applySelectedMoveReward(moveResult.isExploitMode(), passedGameState.getNetworkInput(), environmentReward, passedGameState.isFinal());		
	}	
	
	private void playSelectedMove(int coordX, int coordY, boolean isBestMove, double maxValue, GameState passedGameState) {
		String movement = "" + coordX + "," + coordY + "->" + maxValue;

		// move the pawn
		passedGameState.usePawn(this.turn, coordX, coordY);
	
		//TODO check for validity
		passedGameState.pawnsToBinaryArray();

		if (Settings.logMode == Settings.SIMPLE_LOG || Settings.logMode == Settings.BOTH_LOG) {
			addMoveLog(movement);
		}
		
		if (Settings.logMode == Settings.EXTENDED_LOG || Settings.logMode == Settings.BOTH_LOG) {
			addExtMoveLog((isBestMove ? "EXT" : "EXR" ) + "," + movement);
		} 	
		
		if (isBestMove) {
			if (this.turn == Settings.WHITE_PLAYER) { 
				passedGameState.setCurrentWValue(maxValue);
			} else {
				passedGameState.setCurrentBValue(maxValue);
			}
		}
	}	
	
	public void finishGameSession() {
		aiAgent.finishGameSession();
	}
	
	public void addMoveLog(String s) {
		movesLog.append(s);
		movesLog.append("\n");

	}

	public void addExtMoveLog(String s) {
		extMovesLog.append(s);
		extMovesLog.append("\n");

	}	
}
