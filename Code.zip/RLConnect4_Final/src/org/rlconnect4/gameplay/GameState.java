package org.rlconnect4.gameplay;

import java.util.Vector;

import org.rlgame.common.*;
import org.rlconnect4.experiment.Settings;

public class GameState  {

	private String gameTag;
	private double currentWValue;
	private double currentBValue;

	private int[][] gameGrid;
	
	private double[] networkInput;

	public GameState() {
		initGameGrid();
		currentWValue = 0;
		currentBValue = 0;
	}

	public GameState(int [][] grid) {
		copyGameGrid(grid);
		currentWValue = 0;
		currentBValue = 0;
	}
	
	
	
	public String getGameTag() {
		return gameTag;
	}

	public void setGameTag(String gameTag) {
		this.gameTag = gameTag;
	}

	private void initGameGrid() {
		gameGrid = new int[Settings.DIMBOARDX][Settings.DIMBOARDY];
		for (int i = 0; i < Settings.DIMBOARDX; i++) {
			for (int j = 0; j < Settings.DIMBOARDY; j++) {
				gameGrid[i][j] = 0;
			}
		}
		
//		whitePawn = new int[Settings.NUMOFPAWNS];
//		blackPawn = new int[Settings.NUMOFPAWNS];
//		for (int i = 0; i < Settings.NUMOFPAWNS; i++) {
//			whitePawn[i] = 0;
//			blackPawn[i] = 0;
//		}
	}

	private void copyGameGrid(int [][] grid) {
		gameGrid = new int[Settings.DIMBOARDX][Settings.DIMBOARDY];
		for (int i = 0; i < Settings.DIMBOARDX; i++) {
			for (int j = 0; j < Settings.DIMBOARDY; j++) {
				gameGrid[i][j] = grid[i][j];
			}
		}
		
	}
	
	
	public Vector <ObservationCandidateMove> getAllPossibleMovesForPlayer(int turn, int[][] outGrid) {
		Vector<ObservationCandidateMove> toRet = new Vector<ObservationCandidateMove>(); 
		
		//always 0
		//int pawnId = 0;
		
		for (int i = 0; i < Settings.DIMBOARDX; i++) {
			for (int j = 0; j < Settings.DIMBOARDY; j++) {
				if( outGrid[i][j] == 0 ) {
					toRet.add(this.getMoveTargetGameState(turn, i, j));
					break;
				}
			}
		}
		
		return toRet;
	}

	// check for winner or tie
	public boolean isFinal() {
		int ret = checkResult(this.gameGrid);
		
		return ret != -1 ? true : false;
	}
	
	public int getResult() {
		return getResult(this.gameGrid); 
	}

	//result 
	//-1 live
	//0 final tie
	//1 final white wins
	//2 final black wins
	public int getResult(int [][] grid) {
		return checkResult(grid); 
	}
	
	/**
	* checkResult method.
	*
	*
	*Note this method is build specifically for the 6*7 grid
	*
	*TODO
	*
	* This method returns 
	* -1 if none wins
	* 0 if tie
	* 1 if white wins
	* 2 if black wins
	* 
	* players has won the game.
	*/
	public int checkResult(int [][] grid) {

		int result = -1;
		// check for a horizontal win
		
		//row stands for the y axis and column stands for the x axis
		for (int row=0; row<6; row++) {
			for (int column=0; column<4; column++) {
				if (grid[column][row] != 0 &&
						grid[column][row] == grid[column+1][row] &&
						grid[column][row] == grid[column+2][row] &&
						grid[column][row] == grid[column+3][row]) {
					result = grid[column][row];
				}
			}
		}
		
		// check for a vertical win
		for (int row=0; row<3; row++) {
			for (int column=0; column<7; column++) {
				if (grid[column][row] != 0 &&
						grid[column][row] == grid[column][row+1] &&
						grid[column][row] == grid[column][row+2] &&
						grid[column][row] == grid[column][row+3]) {
					result = grid[column][row];
				}
			}
		}

		// check for a diagonal win (positive slope)
		for (int row=0; row<3; row++) {
			for (int column=0; column<4; column++) {
				if (grid[column][row] != 0 &&
						grid[column][row] == grid[column+1][row+1] &&
						grid[column][row] == grid[column+2][row+2] &&
						grid[column][row] == grid[column+3][row+3]) {
					result = grid[column][row];
				}
			}
		}
		
		// check for a diagonal win (negative slope)
		for (int row=3; row<6; row++) {
			for (int column=0; column<4; column++) {
				if (grid[column][row] != 0 &&
						grid[column][row] == grid[column+1][row-1] &&
						grid[column][row] == grid[column+2][row-2] &&
						grid[column][row] == grid[column+3][row-3]) {
					result = grid[column][row];
				}
			}
		}
		
		//check for tie
		if (result == -1) {
			boolean isTie = true;
			for (int column = 0; column < Settings.DIMBOARDX; column++) {
				if (grid[column][Settings.DIMBOARDY - 1] == 0) {
					isTie = false;
					break;
				}
			}
			
			if (isTie) {
				System.out.println("This is a tie result..............");
				result = 0;
			}
		}
		
		return result;
	}
	
	
	/*
	 * Get the occuring cloned Gamestate after playing the proposed move in a cloned board
	 */
	public ObservationCandidateMove getMoveTargetGameState(int turn, int coordX, int coordY) {
		// clone the board
		
		//new object is returned to check
		GameState tempState = new GameState(this.gameGrid);

		// move the cloned pawn
		tempState.usePawn(turn, coordX, coordY);
		
		tempState.pawnsToBinaryArray();

		ObservationCandidateMove moveItem = new ObservationCandidateMove();
		//always set to 0 for connect 4
		moveItem.setPawnId(0);
		moveItem.setTargetCoordX(coordX);
		moveItem.setTargetCoordY(coordY);
		moveItem.setInputNode(tempState.networkInput);
		moveItem.setEnvReward(tempState.getReward(turn));
		
		return moveItem;
	}

	public void usePawn(int turn, int coordX, int coordY) {
		this.gameGrid[coordX][coordY] = turn;
	}
	
	public void undoUsePawn(int coordX, int coordY) {
		this.gameGrid[coordX][coordY] = 0;
	}

	
	
	public void setCurrentWValue(double timi) {
		currentWValue = timi;
	}

	public void setCurrentBValue(double timi) {
		currentBValue = timi;
	}

	public double getCurrentWValue() {
		return currentWValue;
	}

	public final double getCurrentBValue() {
		return currentBValue;
	}

	//TODO
	
	// Statistics 
	public final String getFinalStateStats() {
		//TODO maybe used pawns
//
//		toRet += "" + whiteLeft + "|" + blackLeft + "|";
//		
		return getNetworkInputString();
	}

	public final String getNetworkInputString() {
		String toRet = "";
		
		this.pawnsToBinaryArray();
		
		for (int i = 0; i < networkInput.length; i++) {
			toRet += String.valueOf((int) networkInput[i]);
		}
		
		return toRet;
	}

	
	

	public int[][] getGameGrid() {
		return gameGrid;
	}


	
	void pawnsToBinaryArray() {
		pawnsToBinaryArray(this.gameGrid);
	}

	// transforms the pawns configuration to a binary array, that we use for input to the net 
	// for each square we have 2 values,
	// one for each player, the appropriate value is set to 1 or both are set to zero 
	
	
	
	// finally there are 3 more values, 1 for tie result 1 for white win and another for black win
	private void pawnsToBinaryArray(int[][] grid) {
		int pos = 0;
		int shortcut = (2 * Settings.DIMBOARDX * Settings.DIMBOARDY) - 1;
		double [] inputNode = new double[Settings.NEURAL_INPUT_SIZE + 1]; 

		for (int i = 0; i < Settings.NEURAL_INPUT_SIZE + 1; i++) {
			inputNode[i] = 0.0; 
		}
		
		for (int i = 0; i < Settings.DIMBOARDX; i++) {
			for (int j = 0; j < Settings.DIMBOARDY; j++) {
				if( grid[i][j] == Settings.WHITE_PLAYER ) {
					pos = i  * (Settings.DIMBOARDX - 1)  + j;
					inputNode[pos] = 1.0;
				} 

				if( grid[i][j] == Settings.BLACK_PLAYER ) {
					pos = i  * (Settings.DIMBOARDX - 1)  + j + (Settings.DIMBOARDX * Settings.DIMBOARDY);
					inputNode[pos] = 1.0;
				} 
			}
		}

		int result = this.getResult(grid);

		if (result == 0) { inputNode[shortcut] = 1.0; } 
		if (result == 1) { inputNode[shortcut + 1] = 1.0; } 
		if (result == 2) { inputNode[shortcut + 2] = 1.0; } 
		
		this.networkInput = inputNode;
	}

	
	
	public  double [] getNetworkInput() {
		return networkInput;
	}

	
	public double getReward(int turn) {
		int result = this.getResult();
		
		return getReward(turn, result);
	}
	
	private final double getReward(int turn, int finalState) {
		//-1 live
		//0 final tie
		//1 final white wins
		//2 final black wins

		if (finalState == -1 || finalState == 0) { return 0;}
		
		if (finalState == 1 && turn == Settings.WHITE_PLAYER) { return Settings.whiteReward;}
		if (finalState == 1 && turn == Settings.BLACK_PLAYER) { return -Settings.blackReward;}
		
		if (finalState == 2 && turn == Settings.WHITE_PLAYER) { return -Settings.whiteReward;}
		if (finalState == 2 && turn == Settings.BLACK_PLAYER) { return Settings.blackReward;}

		return 0;
	}
	
	
	public void printGameBoard() {
		for (int j = Settings.DIMBOARDY - 1; j >= 0 ; j--) {
			for (int i = 0; i < Settings.DIMBOARDX; i++) {
				System.out.print(this.gameGrid[i][j] + " ");
			}
			System.out.println(" ");
		}
		System.out.println(" ");
	}

}
