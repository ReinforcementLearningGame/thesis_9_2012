package org.rlconnect4.gameplay;

import org.rlconnect4.experiment.Settings;
import org.rlconnect4.experiment.History;

import java.util.Random;
import java.util.StringTokenizer;

/*
 * 
 * Spiel is ''game'' in german
 * 
 */

public class Spiel {

	private GameState currentGameState;
	private IPlayer whitePlayer; 
	private IPlayer blackPlayer; 

	public Spiel() {
		currentGameState = new GameState();

		if (Settings.PLAYER_W_MODE == Settings.MM_PLAYER) {
			whitePlayer = new MMPlayer(Settings.WHITE_PLAYER, Settings.PLAYER_W_PLIES, Settings.BLACK_PLAYER);
		} else if (Settings.PLAYER_W_MODE == Settings.RANDOM_PLAYER) {
			whitePlayer = new RandomPlayer(Settings.WHITE_PLAYER);
		} else if (Settings.PLAYER_W_MODE == Settings.HUMAN_PLAYER) {
			System.out.println("[ Human mode isn't supported in the current version : Program execution will be finished]");
			System.exit(0);
		} else {
			//Settings.RL_PLAYER
			whitePlayer = new RLPlayer(Settings.WHITE_PLAYER);
		}

		if (Settings.PLAYER_B_MODE == Settings.MM_PLAYER) {
			blackPlayer = new MMPlayer(Settings.BLACK_PLAYER, Settings.PLAYER_B_PLIES, Settings.WHITE_PLAYER);			
		} else if (Settings.PLAYER_B_MODE == Settings.RANDOM_PLAYER) {
			blackPlayer = new RandomPlayer(Settings.BLACK_PLAYER);
		} else if (Settings.PLAYER_B_MODE == Settings.HUMAN_PLAYER) {
			System.out.println("[ Human mode isn't supported in the current version : Program execution will be finished]");
			System.exit(0);
		} else  {
			//Settings.RL_PLAYER
			blackPlayer = new RLPlayer(Settings.BLACK_PLAYER);
		}

	}

	public Spiel(int [][] grid) {
		currentGameState = new GameState(grid);

		if (Settings.PLAYER_W_MODE == Settings.MM_PLAYER) {
			whitePlayer = new MMPlayer(Settings.WHITE_PLAYER, Settings.PLAYER_W_PLIES, Settings.BLACK_PLAYER);
		} else if (Settings.PLAYER_W_MODE == Settings.RANDOM_PLAYER) {
			whitePlayer = new RandomPlayer(Settings.WHITE_PLAYER);
		} else if (Settings.PLAYER_W_MODE == Settings.HUMAN_PLAYER) {
			System.out.println("[ Human mode isn't supported in the current version : Program execution will be finished]");
			System.exit(0);
		} else {
			//Settings.RL_PLAYER
			whitePlayer = new RLPlayer(Settings.WHITE_PLAYER);
		}

		if (Settings.PLAYER_B_MODE == Settings.MM_PLAYER) {
			blackPlayer = new MMPlayer(Settings.BLACK_PLAYER, Settings.PLAYER_B_PLIES, Settings.WHITE_PLAYER);			
		} else if (Settings.PLAYER_B_MODE == Settings.RANDOM_PLAYER) {
			blackPlayer = new RandomPlayer(Settings.BLACK_PLAYER);
		} else if (Settings.PLAYER_B_MODE == Settings.HUMAN_PLAYER) {
			System.out.println("[ Human mode isn't supported in the current version : Program execution will be finished]");
			System.exit(0);
		} else  {
			//Settings.RL_PLAYER
			blackPlayer = new RLPlayer(Settings.BLACK_PLAYER);
		}

	}
	
	// A new game is executed each time playSession method is executed
	public String [] playSession(int round, int gameNum) {
		String [] gameResult = {"", ""};
		/* 
		 * counter is used in order to not let a game last forever, 
		 * the maximum number of moves is 10000
		*/
		
		currentGameState.setGameTag("Round: " + String.valueOf(round) + " Game: " + String.valueOf(gameNum) );
		int counter = 1; 
	    if (Settings.FIRST_TURN == Settings.WHITE_PLAYER) {
			while ((currentGameState.getResult() == -1) && (counter < Settings.MAX_MOVES_COUNTER)) {
				whitePlayer.pickMove(currentGameState);
				if ( currentGameState.getResult() == -1) {
					blackPlayer.pickMove(currentGameState);
				}
				counter++;
			}
	    } else {
			while ((currentGameState.getResult() == -1) && (counter < Settings.MAX_MOVES_COUNTER)) {
				blackPlayer.pickMove(currentGameState);
				if ( currentGameState.getResult() == -1) {
					whitePlayer.pickMove(currentGameState);
				}
				counter++;
			}
	    }
	    
		if (counter < Settings.MAX_MOVES_COUNTER)  {

			int res = currentGameState.getResult();
			
			String winnerStr = "";
			if (res == 0 ) {
				winnerStr = "tie";
			} else if (res == 1){
				winnerStr = "aspros";
			} else {
				winnerStr = "mavros";
			}

			//stats used for the current report
			gameResult[0] = "" + (counter - 1) + "\n";
			gameResult[0] += winnerStr + "\n";
			
			//Extended stats
			gameResult[1] = "" + (counter - 1) + "|";
			gameResult[1] += winnerStr + "|";
			gameResult[1] += currentGameState.getFinalStateStats();
			//currentGameState.printGameBoard();
			storeGameMovesAndStats();
		}
		
		//call finish game on each player
		//aka store neural network weights info
		whitePlayer.finishGameSession();
		blackPlayer.finishGameSession();
		
		return gameResult;
	}

	// Added by Dockos
	public void storeGameMovesAndStats() {
		String name = 	"Connect4_cVSc_" + Settings.DIMBOARDX + "_" + 
						Settings.DIMBOARDY + "_" + Settings.NUMOFPAWNS + 
						"_game_" + Math.abs(new Random().nextInt());		


		if (Settings.logMode == Settings.SIMPLE_LOG || Settings.logMode == Settings.BOTH_LOG) {
			storeSimpleGamesMovesLog(name);
		}
		
		if (Settings.logMode == Settings.EXTENDED_LOG || Settings.logMode == Settings.BOTH_LOG) {
			storeExtendedGamesMovesLog(name);
		} 
				

	}

	public void storeSimpleGamesMovesLog(String fname) {
		String firstPlayerHistory = "";
		String secondPlayerHistory = "";

		if (Settings.FIRST_TURN == Settings.WHITE_PLAYER) {
			firstPlayerHistory  = whitePlayer.getMovesLog().toString();
			secondPlayerHistory = blackPlayer.getMovesLog().toString();
		} else {
			firstPlayerHistory  = blackPlayer.getMovesLog().toString();
			secondPlayerHistory = whitePlayer.getMovesLog().toString();
		}

		
		History gameHistory = new History();
		StringTokenizer stW = new StringTokenizer(firstPlayerHistory.replace('\n', ' '));
		StringTokenizer stB = new StringTokenizer(secondPlayerHistory.replace('\n', ' '));
		String gameMoves = "";
		while (stB.hasMoreTokens()) {
			gameMoves += stW.nextToken() + "\t" + stB.nextToken() + "\n";
		}
		// o aspros mporei na exei mia akomi kinisi => check it
		if (stW.hasMoreTokens()) {
			gameMoves += stW.nextToken() + '\n';
		}

		gameHistory.writeToFile(gameMoves, fname, 0);
	}
	
	public void storeExtendedGamesMovesLog(String fname) {
		String firstExtPlayerHistory = "";
		String secondExtPlayerHistory = "";

		if (Settings.FIRST_TURN == Settings.WHITE_PLAYER) {
			firstExtPlayerHistory  = whitePlayer.getExtMovesLog().toString();
			secondExtPlayerHistory = blackPlayer.getExtMovesLog().toString();
		} else {
			firstExtPlayerHistory  = blackPlayer.getExtMovesLog().toString();
			secondExtPlayerHistory = whitePlayer.getExtMovesLog().toString();
		}

		History gameExtHistory = new History();
		StringTokenizer stWext = new StringTokenizer(firstExtPlayerHistory.replace('\n', ' '));
		StringTokenizer stBext = new StringTokenizer(secondExtPlayerHistory.replace('\n', ' '));
		String gameMovesExt = "";
		while (stBext.hasMoreTokens()) {
			gameMovesExt += stWext.nextToken() + "\t" + stBext.nextToken() + "\n";
		}
		// o aspros mporei na exei mia akomi kinisi => check it
		if (stWext.hasMoreTokens()) {
			gameMovesExt += stWext.nextToken() + '\n';
		}

		gameExtHistory.writeToFile(gameMovesExt, fname + "_ext", 0);
	
	}

	
	// A game with a predefined state is executed 
	public String [] testSession() {
		String [] gameResult = {"", ""};
		/* 
		 * counter is used in order to not let a game last forever, 
		 * the maximum number of moves is 10000
		*/
		
		currentGameState.setGameTag("Test Session: ");
		
		
		int counter = 1; 
		//actually next turn
	    if (Settings.FIRST_TURN == Settings.WHITE_PLAYER) {
			while ((currentGameState.getResult() == -1) && (counter < Settings.MAX_MOVES_COUNTER)) {
				whitePlayer.pickMove(currentGameState);
				if ( currentGameState.getResult() == -1) {
					blackPlayer.pickMove(currentGameState);
				}
				counter++;
			}
	    } else {
			while ((currentGameState.getResult() == -1) && (counter < Settings.MAX_MOVES_COUNTER)) {
				blackPlayer.pickMove(currentGameState);
				if ( currentGameState.getResult() == -1) {
					whitePlayer.pickMove(currentGameState);
				}
				counter++;
			}
	    }
	    
		if (counter < Settings.MAX_MOVES_COUNTER)  {

			int res = currentGameState.getResult();
			
			String winnerStr = "";
			if (res == 0 ) {
				winnerStr = "tie";
			} else if (res == 1){
				winnerStr = "aspros";
			} else {
				winnerStr = "mavros";
			}

			//stats used for the current report
			gameResult[0] = "" + (counter - 1) + "\n";
			gameResult[0] += winnerStr + "\n";
			
			//Extended stats
			gameResult[1] = "" + (counter - 1) + "|";
			gameResult[1] += winnerStr + "|";
			gameResult[1] += currentGameState.getFinalStateStats();
			//currentGameState.printGameBoard();
			storeGameMovesAndStats();
		}
		
		//call finish game on each player
		//aka store neural network weights info
		whitePlayer.finishGameSession();
		blackPlayer.finishGameSession();
		
		return gameResult;
	}
	
}
