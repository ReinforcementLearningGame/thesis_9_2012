package org.rlconnect4.gameplay;


public interface  IPlayer {

	public int getId();
	public int getPlayerType();

	public StringBuffer getMovesLog();
	public StringBuffer getExtMovesLog();

	public void pickMove(GameState passedGameState);
	public void finishGameSession();
}
