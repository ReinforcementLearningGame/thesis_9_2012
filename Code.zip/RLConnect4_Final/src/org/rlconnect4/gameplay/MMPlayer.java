package org.rlconnect4.gameplay;

import java.util.HashMap;
import java.util.Random;
import java.util.Vector;

import org.rlconnect4.experiment.Settings;
import org.rlgame.common.*;
import org.rlgame.ai.AIAgent;

public class MMPlayer implements IPlayer {
	private int id; //id stands for the turn
	private int playerType;
	private int turn;

	private AIAgent aiAgent;
	private StringBuffer movesLog;
	private StringBuffer extMovesLog;
	
	private HashMap<String,Double>[] positionsTable;

    private Random eSoftDecision = new Random();
    private Random eRand = new Random();
    private Random eqEvalMovesDecision = new Random();    
    
    private double eGreedyValue;
	private int traversalDepth;
	private int opponentPlayer;

	private  boolean chooseFirst  = false;	
	  
	@SuppressWarnings("unchecked")
	public MMPlayer(int ident, int depth, int opponent) {
		this.id = ident;
		this.turn = ident;
		this.movesLog = new StringBuffer();
		
		this.extMovesLog = new StringBuffer();
		extMovesLog.append("Mode:MM,Turn:");
		extMovesLog.append(this.turn);
		extMovesLog.append("\n");			
		
		this.playerType =  Settings.MM_PLAYER;
		this.traversalDepth = depth;
		this.opponentPlayer = opponent;
		positionsTable = new HashMap[this.traversalDepth];

		for (int i = 0; i < this.traversalDepth; i++){
			positionsTable[i] = new HashMap<String,Double>(1000);  
		}		
		
		eGreedyValue = this.turn == Settings.WHITE_PLAYER ? Settings.eGreedyWhite : Settings.eGreedyBlack;
		
		/*Instatiate AIAgent with the game mode info*/
		aiAgent = new AIAgent(this.turn, 
				eGreedyValue,
				Settings.NEURAL_INPUT_SIZE, 
				(this.turn == Settings.WHITE_PLAYER ? Settings.whiteNeuralHiddenSize  : Settings.blackNeuralHiddenSize), 
				Settings.NEURAL_OUTPUT_SIZE, 
				(this.turn == Settings.WHITE_PLAYER ? Settings.whiteGamma : Settings.blackGamma),
				(this.turn == Settings.WHITE_PLAYER ? Settings.whiteLamda : Settings.blackLamda),
				(this.turn == Settings.WHITE_PLAYER ? Settings.whiteVWeightsName : Settings.blackVWeightsName),
				(this.turn == Settings.WHITE_PLAYER ? Settings.whiteWWeightsName : Settings.blackWWeightsName)
				);
	}

	public int getId() {
		return id;
	}

	public int getPlayerType() {
		return playerType;
	}

	public StringBuffer getMovesLog() {
		return movesLog;
	}

	
	//changed on 29/5/2012, added exploration mode on the mm pickMove
	public void pickMove(GameState passedGameState) {
		
		int depth = traversalDepth;
	    int idx = -1;

	    double maxValue = -1000;
	    double value = maxValue;
	    
	    double alpha = Settings.LOSS;
	    double beta = Settings.WIN;	

	    for (int i = 0; i < this.traversalDepth; i++){
	    	positionsTable[i].clear();    
	    }
	    
		double eSoft = eSoftDecision.nextDouble();

		//if eSoft is > = than eGreedyValue (def = 0.9) then we explore
		boolean exploreMove = (eSoft >=  eGreedyValue) ? true : false; 
		Vector<ObservationCandidateMove> movesVector;
		ObservationCandidateMove selMove;
		if (exploreMove) {
			movesVector = passedGameState.getAllPossibleMovesForPlayer(this.turn, passedGameState.getGameGrid());

			int movesNum = movesVector.size();
			int ee = eRand.nextInt(movesNum);
			selMove = movesVector.get(ee);

			//MaxValue calc added on 29/7/2012 
			double aux = aiAgent.checkAIResponse(selMove.getInputNode()) ;		
			maxValue = aux + selMove.getEnvReward();
					
		} else {
			Vector <Integer> maxValueMoves = new Vector<Integer>();
			//MiniMaxState is just a new copy clone of game state 
			GameState miniMaxState =  new GameState(passedGameState.getGameGrid());
	
			//all legal moves for player
			movesVector = miniMaxState.getAllPossibleMovesForPlayer(this.turn, miniMaxState.getGameGrid());

			for (int i = 0; i < movesVector.size(); i++) {
				ObservationCandidateMove moveRec = movesVector.get(i);
				if (( moveRec.getTargetCoordX() >= 0 && moveRec.getTargetCoordX() < Settings.DIMBOARDX) &&  
						( moveRec.getTargetCoordY() >= 0 && moveRec.getTargetCoordY() < Settings.DIMBOARDY ) ) {			
					value = maxMode(depth-1, miniMaxState, moveRec.getPawnId(), moveRec.getTargetCoordX(), moveRec.getTargetCoordY(), alpha, beta);

					//Changed on 17/9					
//					if (value > maxValue) { //if it is the biggest value, keep it
//						maxValue = value;
//						idx = i;
//			        }
					if (value > maxValue) { 
						maxValue = value;
						maxValueMoves.clear();
						maxValueMoves.add(i);
					} else if (value == maxValue) {	
						maxValueMoves.add(i);
					}					
				}
			}
			
			//added on 17/9/2012
			if (maxValueMoves.size() > 1 && (! chooseFirst)) {
				int cc = eqEvalMovesDecision.nextInt(maxValueMoves.size());
				idx = (Integer) maxValueMoves.get(cc);
				debugLog("MMPlayer Pick Move : Picked Idx " + cc +" out of :" + (maxValueMoves.size() - 1) + " moves with evaluation : "+ maxValue );
			} else {
				idx =  (Integer) maxValueMoves.get(0);
			}
			
			selMove = movesVector.get(idx);
			debugLog("Choosen Move: " + selMove.getPawnId() + " " + selMove.getTargetCoordX() + ","+  selMove.getTargetCoordY()+" "+ " with max value " + maxValue);					
		}
		

		if (maxValue >= 100.0 || maxValue <= 0.0) {
			debugLog(passedGameState.getGameTag() + " : MM player Turn " + String.valueOf(this.turn) + " MaxValue = " + String.valueOf(maxValue));
		}

		playSelectedMove(selMove.getTargetCoordX(), selMove.getTargetCoordY(), (! exploreMove), maxValue, passedGameState);
		 
		///////
		//Note the environment reward is called from the 
		//actual State after the move has been played
		//it isn't called from the miniMaxState that is the clone of the 
		//actual state that we use for the the minimax search
		double environmentReward = passedGameState.getReward(this.turn);
		//modified on 29/7 in order to pass exploit/explore mode correctly
		aiAgent.applySelectedMoveReward((! exploreMove), passedGameState.getNetworkInput(), environmentReward, passedGameState.isFinal());		

		
	}
	
	
	private void playSelectedMove(int coordX, int coordY, boolean isBestMove, double maxValue, GameState passedGameState) {
		String movement = "" + coordX + "," + coordY + "->" + maxValue;

		// move the pawn
		passedGameState.usePawn(this.turn, coordX, coordY);
	
		//TODO check for validity
		passedGameState.pawnsToBinaryArray();

		if (Settings.logMode == Settings.SIMPLE_LOG || Settings.logMode == Settings.BOTH_LOG) {
			addMoveLog(movement);
		}
		
		if (Settings.logMode == Settings.EXTENDED_LOG || Settings.logMode == Settings.BOTH_LOG) {
			addExtMoveLog((isBestMove ? "EXT" : "EXR" ) + "," + movement);
		} 		
		
		if (isBestMove) {
			if (this.turn == Settings.WHITE_PLAYER) { 
				passedGameState.setCurrentWValue(maxValue);
			} else {
				passedGameState.setCurrentBValue(maxValue);
			}
		}
	}	
	


	//MAX Mode is played for the current player (turn)
	public double maxMode(int depth, GameState tempGameState, int iPawn, int coordX, int coordY, double a, double b) {
		double value = 1000;
		double alpha = a;
		double beta = b;
		String posString;
		Double posValue;
		double wValue;

		//Alpha-Beta pruning
		if (alpha >= beta) {
			return beta;
		}
		
		// move the pawn on the cloned gameState object
		tempGameState.usePawn(this.turn, coordX, coordY);

		//TODO check for validity
		tempGameState.pawnsToBinaryArray();
		//this is just the NN evaluation environment reward isn't counted here
		wValue = aiAgent.checkAIResponse(tempGameState.getNetworkInput());
		
		
		
		posString = tempGameState.getNetworkInputString();
		posValue = positionsTable[depth].get(posString);
		
		
		//If evaluation is located then use this value
		if (posValue != null) {
			// Undo the move before returning 
			tempGameState.undoUsePawn(coordX, coordY);

			return posValue;
		}
		
		int result = tempGameState.getResult();

		//updated on 24/6 -- correction of the result evaluation logic, take into account max player
		if (result > -1) {
			//final result

			//Tie
			if (result == 0) {
				//Tie reward is 0 : Corrected on 29/7/2012
				positionsTable[depth].put(posString, new Double(0.0));
				// Undo the move before returning 
				tempGameState.undoUsePawn(coordX, coordY);

				return 0;
			}
			 
			//if max Player = WHITE_PLAYER
			if (this.turn == Settings.WHITE_PLAYER) { 
				//max player wins 
				if (result == 1) {
					positionsTable[depth].put(posString, new Double(Settings.WIN));
					// Undo the move before returning 
					tempGameState.undoUsePawn(coordX, coordY);
					return Settings.WIN + depth;
				}
	
				//max player looses
				if (result == 2) {
					positionsTable[depth].put(posString, new Double(Settings.LOSS));
					// Undo the move before returning 
					tempGameState.undoUsePawn(coordX, coordY);
					return Settings.LOSS - depth;
				}
			} else {
				//turn, max player == Black_Player
				//max player wins 
				if (result == 2) {
					positionsTable[depth].put(posString, new Double(Settings.WIN));
					// Undo the move before returning 
					tempGameState.undoUsePawn(coordX, coordY);
					return Settings.WIN + depth;
				}
	
				//max player losses
				if (result == 1) {
					positionsTable[depth].put(posString, new Double(Settings.LOSS));
					// Undo the move before returning 
					tempGameState.undoUsePawn(coordX, coordY);
					return Settings.LOSS - depth;
				}
				
			}
		}
		
		if (depth == 0) {
			// Undo the move before returning 
			tempGameState.undoUsePawn(coordX, coordY);
			return wValue;
		}

		
		//all legal moves for player
		Vector<ObservationCandidateMove> oponentMovesVector = tempGameState.getAllPossibleMovesForPlayer(this.opponentPlayer, tempGameState.getGameGrid());

		for (int i = 0; i < oponentMovesVector.size(); i++) {
			ObservationCandidateMove moveRec = oponentMovesVector.get(i);

			//TODO defensive/pessimistic check  
			if (( moveRec.getTargetCoordX() >= 0 && moveRec.getTargetCoordX() < Settings.DIMBOARDX) &&  
					( moveRec.getTargetCoordY() >= 0 && moveRec.getTargetCoordY() < Settings.DIMBOARDY ) ) {			
			//bug fixed/commented out 9/8/2012
			//if ((moveRec.getTargetCoordX() + moveRec.getTargetCoordY()) != 0) {
				value = minMode(depth - 1, tempGameState, moveRec.getPawnId(), moveRec.getTargetCoordX(), moveRec.getTargetCoordY(), alpha, beta);
			}
			if (value < beta) {
				beta = value;
			}
		}
		positionsTable[depth].put(posString, beta);

		// Undo this level move 
		tempGameState.undoUsePawn(coordX, coordY);

		return beta;
	}

	//MIN Mode is played for the opponentPlayer	
	public double minMode(int depth, GameState tempGameState, int iPawn, int coordX, int coordY, double a, double b) {
		double value = -1000;
		double alpha = a;
		double beta = b;
		String posString;
		Double posValue;
		// double wValue;

		if (alpha >= beta) {
			return alpha;
		}
		
		// use the pawn on the cloned gameState object
		tempGameState.usePawn(this.opponentPlayer, coordX, coordY);
		
		posString = tempGameState.getNetworkInputString();
		
		posValue = positionsTable[depth].get(posString);
		if (posValue != null) {
			// Undo this level move 
			tempGameState.undoUsePawn(coordX, coordY);

			return posValue;
		}

		
		int result = tempGameState.getResult();
		
		//updated on 24/6 -- correction of the result evaluation logic, take into account max player
		if (result > -1) {

			//Tie = 0
			if (result == 0) {
				//Tie reward is 0 : Corrected on 9/8/2012
				positionsTable[depth].put(posString, new Double(0.0));
				// Undo this level move				
				tempGameState.undoUsePawn(coordX, coordY);				
				return 0;
			}

			//if max Player = WHITE_PLAYER
			if (this.turn == Settings.WHITE_PLAYER) { 
				//max Player wins
				if (result == 1) {
					positionsTable[depth].put(posString, new Double(Settings.WIN));
					// Undo this level move 
					tempGameState.undoUsePawn(coordX, coordY);
					return Settings.WIN + depth;
				}
	
				//max Player looses
				if (result == 2) {
					positionsTable[depth].put(posString, new Double(Settings.LOSS));
					// Undo this level move 
					tempGameState.undoUsePawn(coordX, coordY);
					return Settings.LOSS - depth;
				}
			} else {
				//max Player = BLACK_PLAYER
				//max Player wins
				if (result == 2) {
					positionsTable[depth].put(posString, new Double(Settings.WIN));
					// Undo this level move 
					tempGameState.undoUsePawn(coordX, coordY);
					return Settings.WIN + depth;
				}
	
				//max Player wins
				if (result == 1) {
					positionsTable[depth].put(posString, new Double(Settings.LOSS));
					// Undo this level move 
					tempGameState.undoUsePawn(coordX, coordY);
					return Settings.LOSS - depth;
				}
			}
		}

		if (depth == 0) {
			// Undo this level move
			tempGameState.undoUsePawn(coordX, coordY);			
			return (Settings.WIN + Settings.LOSS) / 2.0;
		}
		
		//all legal moves for player
		Vector<ObservationCandidateMove> oponentMovesVector = tempGameState.getAllPossibleMovesForPlayer(this.turn, tempGameState.getGameGrid());
		
		for (int i = 0; i < oponentMovesVector.size(); i++) {
			ObservationCandidateMove moveRec = oponentMovesVector.get(i);
			//TODO defensive/pessimistic check  
			if (( moveRec.getTargetCoordX() >= 0 && moveRec.getTargetCoordX() < Settings.DIMBOARDX) &&  
					( moveRec.getTargetCoordY() >= 0 && moveRec.getTargetCoordY() < Settings.DIMBOARDY ) ) {			
			//bug fixed/commented out 9/8/2012
			//if ((moveRec.getTargetCoordX() + moveRec.getTargetCoordY()) != 0) {
					value = maxMode(depth - 1, tempGameState, moveRec.getPawnId(), moveRec.getTargetCoordX(), moveRec.getTargetCoordY(), alpha, beta);
				if (value > alpha) {
					alpha = value;
				}
			}
		}
		
		positionsTable[depth].put(posString, alpha);
		// Undo this level move
		tempGameState.undoUsePawn(coordX, coordY);			
		return alpha;
	}		
	
	public void finishGameSession() {
		aiAgent.finishGameSession();
	}
	
	
	public void addMoveLog(String s) {
		movesLog.append(s);
		movesLog.append("\n");
	}

	public void addExtMoveLog(String s) {
		extMovesLog.append(s);
		extMovesLog.append("\n");

	}	
	
	public StringBuffer getExtMovesLog() {
		return extMovesLog;
	}		

	private void debugLog(String s) {
		if (Settings.debugMode) {
			System.out.println(s);
		}
	}
}
