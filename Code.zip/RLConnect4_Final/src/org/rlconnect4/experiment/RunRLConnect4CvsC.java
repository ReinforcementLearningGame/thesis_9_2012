package org.rlconnect4.experiment;

import java.io.File;
import java.util.Date;
import org.rlconnect4.gameplay.Spiel;


// Main Class, it initiates history (statistics) and begins a Connect4 experiment session

public class RunRLConnect4CvsC  {
	static int metritis = 0;

	static int gamesNumber = 10;
	static int roundsNumber = 5;
	
	static StringBuffer gameStats; // used for the statistics
	static StringBuffer extendedStats; // used for the statistics

	// start logfile
	public static void saveStats() {
		
		if (Settings.logMode == Settings.SIMPLE_LOG || Settings.logMode == Settings.BOTH_LOG) {
			History statistics = new History();
			statistics.writeToFile(gameStats.toString(), "_stats", 1);
		}
		
		if (Settings.logMode == Settings.EXTENDED_LOG || Settings.logMode == Settings.BOTH_LOG) {
			History extendedStatistics = new History();
			extendedStatistics.writeToFile(extendedStats.toString(), "_extended_stats", 1);
		} 	
		
	}

	private static File makeGamesDirectory() {
		Date myDate = new Date();
		String helpName = myDate.toString();
		helpName = helpName.substring(0, 19);
		helpName = helpName.replace(':', ' ');
		helpName = helpName + ".gamedir";
		File dir = new File(helpName);
		return dir;
	}

	public static void main(String[] args) {
		File gamedir = null;
		
		argumentsValidation(args);

		gamedir = makeGamesDirectory();
		gamedir.mkdir();
		History.Path = gamedir.getAbsolutePath();
		gameStats = new StringBuffer("");
		extendedStats = new StringBuffer("");

		System.out.println("\n");
		System.out.println("**************************************************************************************");
		
		System.out.println("[Experiment Session Settings]");
		System.out.println("[White Player Mode] [ " + Settings.getPlayerMode(Settings.WHITE_PLAYER) + " ]");
		System.out.println("[Black Player Mode] [ " + Settings.getPlayerMode(Settings.BLACK_PLAYER) + " ]");
		System.out.println("[First Player] [ " + Settings.FIRST_TURN + " ]");

		if (Settings.PLAYER_W_MODE == Settings.MM_PLAYER) {
			System.out.println("[White Player MinMax Depth] [ " + Settings.PLAYER_W_PLIES + " ]");
		}
		if (Settings.PLAYER_B_MODE == Settings.MM_PLAYER) {
			System.out.println("[Black Player MinMax Depth] [ " + Settings.PLAYER_B_PLIES + " ]");
		}
		
		System.out.println("[Rounds] [ " + roundsNumber + " ]");
		System.out.println("[Games] [ " + gamesNumber + " ]");
		System.out.println("[whiteLamda] [ " + Settings.whiteLamda + " ]");
		System.out.println("[blackLamda] [ " + Settings.blackLamda + " ]");

		System.out.println("[whiteGamma] [ " + Settings.whiteGamma + " ]");
		System.out.println("[blackGamma] [ " + Settings.blackGamma + " ]");
		
		System.out.println("[whiteReward] [ " + Settings.whiteReward + " ]");
		System.out.println("[blackReward] [ " + Settings.blackReward + " ]");
		
		System.out.println("[eGreedyWhite] [ " + Settings.eGreedyWhite + " ]");
		System.out.println("[eGreedyBlack] [ " + Settings.eGreedyBlack + " ]");
		
		System.out.println("**************************************************************************************");		
		
		for (int kk = 0; kk < roundsNumber; kk++) {
			for (int i = 0; i < gamesNumber; i++) {
				Date startDate = new Date();
				// play a game
				Spiel myGame = new Spiel();
				String [] gameResult;
				gameResult = myGame.playSession(kk, i);
				

				
				if (Settings.logMode == Settings.SIMPLE_LOG || Settings.logMode == Settings.BOTH_LOG) {
					gameStats.append(gameResult[0]);
				}
				
				if (Settings.logMode == Settings.EXTENDED_LOG || Settings.logMode == Settings.BOTH_LOG) {
					extendedStats.append("" + ((kk * gamesNumber ) + i + 1) + "|" + gameResult[1] + "\n");
				} 		
				
				System.out.println("" + (kk + 1) + ":" + (i + 1) + " |" + ((new Date()).getTime() - startDate.getTime()) + " ms");
			}
			System.out.println("telos");
		}
		saveStats();
		System.exit(0);
	}

	
private static void argumentsValidation(String[] args) {
	
	String help = "\nConnect 4 with the RL module of RLGame (Dimitris Kalles & Panagiotis Kanellopoulos)\n"
			+ "\n\t\t##SWITHES##\n"
			+ "\n\t-h Shows the current screen"
			+ "\n\t-g Enter the number of games to be executed in each round"
			+ "\n\t-r Enter the number of game rounds"
			+ "\n\t-wg Enter the discount rate for the white player"
			+ "\n\t-wl Enter the credit assignment factor for the white player"
			+ "\n\t-bg Enter the discount rate for the black player"
			+ "\n\t-bl Enter the credit assignment factor for the black player"
			+ "\n\t-wr Enter the reward value for the white player"
			+ "\n\t-br Enter the reward value for the black player"
			+ "\n\t-we Enter the e-greedy policy number for the white player"
			+ "\n\t-be Enter the e-greedy policy number for the black player\n";

	help += "\n\t-ft Enter first turn/player number : 1 - white, 2 - black"
			+"\n\t-pw White Player Mode 1 - RL, 2 - MinMax, 3 - random, 4 - human (not supported) : Default 1 - RL"
			+"\n\t-pb Black Player Mode 1 - RL, 2 - MinMax, 3 - random, 4 - human (not supported) : Default 1 - RL"
			+"\n\t-dw White Player MinMax Mode Depth Default 3"
			+"\n\t-db Black Player MinMax Mode Depth Default 3"
			+"\n\t-hw White Player Hidden Layer Default InputSize(DIMBOARDX * DIMBOARDY + 3)/2"
			+"\n\t-hb Black Player Hidden Layer Default InputSize(DIMBOARDX * DIMBOARDY + 3)/2"
			+"\n\t-lm Log Mode : 1 - Simple, 2 - Extended, 3 - Both : Default 1 - Simple"
			+"\n\t-dm Debug Mode : 0 - None(Default), 1 - Debug Mode";

	
	
	//TODO hw, hb
	if (args.length == 1 && args[0].contentEquals("-h")) {
		System.out.print(help);
		System.exit(0);
	}

	if (args.length > 39) {
		System.out.print("\nToo many arguments.Termination\n");
		return;
	} else {
		for (int l = 0; l < args.length; l++) {
			if (l % 2 == 0) {
				if (!args[l].startsWith("-")) {
					System.out.printf("\nThe %dth argument has no switch (-). Defaulting...", l + 1);
					continue;
				}
				if (args[l].contentEquals("-g")) {
					try {
						gamesNumber = Integer.parseInt(args[l + 1]);
						System.out.printf("\nThe games per round number has been set up in %s.", args[l + 1]);
					} catch (NumberFormatException numberFormatException) {
						System.out.print("\nInvalid value in games per round number argument. " + numberFormatException.getMessage() + "Defaulting to 100");
					}
					continue;
				}
				if (args[l].contentEquals("-r")) {
					try {
						roundsNumber = Integer.parseInt(args[l + 1]);
						System.out.printf("\nThe games round number has been set up in %s.", args[l + 1]);
					} catch (NumberFormatException numberFormatException) {
						System.out.print("\nInvalid value in games round number argument. " + numberFormatException.getMessage() + "Defaulting to 10");
					}
					continue;
				}
				if (args[l].equals("-wg")) {
					try {
						Settings.whiteGamma = Double.parseDouble(args[l + 1]);
						System.out.printf("\nThe discount rate number for the white player has been set up in %s.", args[l + 1]);
					} catch (NumberFormatException numberFormatException) {
						System.out.print("\nInvalid value in discount rate number argument for the white player. " + numberFormatException.getMessage() + "Defaulting to 0.95");
					}
					continue;
				}
				if (args[l].equals("-wl")) {
					try {
						Settings.whiteLamda = Double.parseDouble(args[l + 1]);
						System.out.printf("\nThe credit asignment factor for the white player has been set up in %s.", args[l + 1]);
					} catch (NumberFormatException numberFormatException) {
						System.out.print("\nInvalid value in credit asignment factor argument for the white player. " + numberFormatException.getMessage() + "Defaulting to 0.5");
					}
					continue;
				}
				if (args[l].equals("-bg")) {
					try {
						Settings.blackGamma = Double.parseDouble(args[l + 1]);
						System.out.printf("\nThe discount rate number for the black player has been set up in %s.", args[l + 1]);
					} catch (NumberFormatException numberFormatException) {
						System.out.print("\nInvalid value in discount rate number argument for the black player. " + numberFormatException.getMessage() + "Defaulting to 0.95");
					}
					continue;
				}
				if (args[l].equals("-bl")) {
					try {
						Settings.blackLamda = Double.parseDouble(args[l + 1]);
						System.out.printf("\nThe credit asignment factor for the black player has been set up in %s.", args[l + 1]);
					} catch (NumberFormatException numberFormatException) {
						System.out.print("\nInvalid value in credit asignment factor argument for the black player. " + numberFormatException.getMessage() + "Defaulting to 0.5");
					}
					continue;
				}
				if (args[l].equals("-wr")) {
					try {
						Settings.whiteReward = Double.parseDouble(args[l + 1]);
						System.out.printf("\nThe reward value for the white player has been set up in %s.", args[l + 1]);
					} catch (NumberFormatException numberFormatException) {
						System.out.print("\nInvalid value in reward value argument for the white player. " + numberFormatException.getMessage() + "Defaulting to 100");
					}
					continue;
				}
				if (args[l].equals("-br")) {
					try {
						Settings.blackReward = Double.parseDouble(args[l + 1]);
						System.out.printf("\nThe reward value for the black player has been set up in %s.", args[l + 1]);
					} catch (NumberFormatException numberFormatException) {
						System.out.print("\nInvalid value in reward value argument for the black player. " + numberFormatException.getMessage() + "Defaulting to 100");
					}
					continue;
				}
				if (args[l].equals("-we")) {
					try {
						Settings.eGreedyWhite = Double.parseDouble(args[l + 1]);
						System.out.printf("\nThe e-Greedy policy number for the white player has been set up in %s.", args[l + 1]);
					} catch (NumberFormatException numberFormatException) {
						System.out.print("\nInvalid value in e-Greedy policy number argument for the white player. " + numberFormatException.getMessage() + "Defaulting to 0.9");
					}
					continue;
				}
				if (args[l].equals("-be")) {
					try {
						Settings.eGreedyBlack = Double.parseDouble(args[l + 1]);
						System.out.printf("\nThe e-Greedy policy number for the black player has been set up in %s.", args[l + 1]);
					} catch (NumberFormatException numberFormatException) {
						System.out.print("\nInvalid value in e-Greedy policy number argument for the black player. " + numberFormatException.getMessage() + "Defaulting to 0.9");
					}
					continue;
				}
				if (args[l].equals("-ft")) {
					try {
						int val = Integer.parseInt(args[l + 1]);
						Settings.FIRST_TURN = (val == Settings.BLACK_PLAYER ? Settings.BLACK_PLAYER : Settings.WHITE_PLAYER);
						System.out.printf("\nThe first player has been set up in %s.", args[l + 1]);
					} catch (NumberFormatException numberFormatException) {
						System.out.print("\nInvalid value for first player argument" + numberFormatException.getMessage() + "Defaulting to 0.9");
					}
					continue;
				}
				if (args[l].equals("-pw")) {
					try {
					    String modeStr = Settings.playerModeSet(Settings.WHITE_PLAYER, Integer.parseInt(args[l + 1]));
						System.out.printf("\nWhite Player Mode has been set to %s.", modeStr);
					} catch (NumberFormatException numberFormatException) {
						System.out.print("\nInvalid value White Player Mode" + numberFormatException.getMessage() + "Defaulting to 1 - RL");
					}
					continue;
				}

				if (args[l].equals("-dw")) {
					try {
						int val = Integer.parseInt(args[l + 1]);
						Settings.PLAYER_W_PLIES = (val > 0  ? val : 3);
						System.out.print("\nWhite Player Depth Plies has been set to " + val);
					} catch (NumberFormatException numberFormatException) {
						System.out.print("\nInvalid White Player Depth value" + numberFormatException.getMessage() + "Defaulting to 3");
					}
					continue;
				}
				
				if (args[l].equals("-pb")) {
					try {
					    String modeStr = Settings.playerModeSet(Settings.BLACK_PLAYER, Integer.parseInt(args[l + 1]));
						System.out.printf("\nBlack Player Mode has been set to %s.", modeStr);
					} catch (NumberFormatException numberFormatException) {
						System.out.print("\nInvalid value Black Player Mode" + numberFormatException.getMessage() + "Defaulting to 1 - RL");
					}
					continue;
				}
				
				if (args[l].equals("-db")) {
					try {
						int val = Integer.parseInt(args[l + 1]);
						Settings.PLAYER_B_PLIES = (val > 0  ? val : 3);
						System.out.print("\nBlack Player Depth Plies has been set to " + val);
					} catch (NumberFormatException numberFormatException) {
						System.out.print("\nInvalid Black Player Depth value" + numberFormatException.getMessage() + "Defaulting to 3");
					}
					continue;
				}

//"\n\t-hw  Default InputSize(DIMBOARDX * DIMBOARDY + 3)/2"
				
				if (args[l].equals("-hw")) {
					try {
						int val = Integer.parseInt(args[l + 1]);
						if (val > 0 ) {
							Settings.whiteNeuralHiddenSize = val;
							System.out.print("\nWhite Player NN Hidden layer size has been set to " + val);
						}
					} catch (NumberFormatException numberFormatException) {
						System.out.print("\nInvalid White Player NN Hidden layer size" + numberFormatException.getMessage() + "Defaulting to InputSize(DIMBOARDX * DIMBOARDY + 3)/2");
					}
					continue;
				}

//"\n\t-hb Black Player Hidden Layer Default InputSize(DIMBOARDX * DIMBOARDY + 3)/2";
				
				if (args[l].equals("-hb")) {
					try {
						int val = Integer.parseInt(args[l + 1]);
						if (val > 0 ) {
							Settings.blackNeuralHiddenSize = val;
							System.out.print("\nBlack Player NN Hidden layer size has been set to " + val);
						}
					} catch (NumberFormatException numberFormatException) {
						System.out.print("\nInvalid Black Player NN Hidden layer size" + numberFormatException.getMessage() + "Defaulting to InputSize(DIMBOARDX * DIMBOARDY + 3)/2");
					}
					continue;
				}
				
				
				if (args[l].equals("-lm")) {
					try {
						int val = Integer.parseInt(args[l + 1]);
						if (val >= 1 && val <= 3) {
							Settings.logMode = val;
							System.out.print("\nLog Mode has been set to " + val);
						}
					} catch (NumberFormatException numberFormatException) {
						System.out.print("\nInvalid Logging Mode " + numberFormatException.getMessage() + " Default Simple mode will be used");
					}
					continue;
				}
				
				if (args[l].equals("-dm")) {
					try {
						int val = Integer.parseInt(args[l + 1]);
						if (val == 0 || val == 1) {
							Settings.debugMode = (val == Settings.DEBUG_MODE ? true : false);
							System.out.print("\nDebug Mode has been set to " + val);
						}
					} catch (NumberFormatException numberFormatException) {
						System.out.print("\nInvalid Debug Mode " + numberFormatException.getMessage() + " Default No Debug mode will be used");
					}
					continue;
				}
				
				
				System.out.printf("\nThe %dth argument is not valid.", l);
				continue;
			}
		}
	}

}
	
	
	
	
}
